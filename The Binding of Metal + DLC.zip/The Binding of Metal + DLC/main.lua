local MetalMod = RegisterMod("MetalMod", 1)
local game = Game()
local Achievements = {}
local json = require("json")
local sound = SFXManager()

function MetalMod.onStart()
	Achievements = json.decode(MetalMod:LoadData())
	if Achievements.CollectorsCoin == nil then Achievements.CollectorsCoin = false end
	if Achievements.BanHammer == nil then Achievements.BanHammer = false end
	if Achievements.ChemicalX == nil then Achievements.ChemicalX = false end
	if Achievements.ReverseCard == nil then Achievements.ReverseCard = false end
	if Achievements.UwUCard == nil then Achievements.UwUCard = false end
	if Achievements.BIGNUT == nil then Achievements.BIGNUT = false end
	if Achievements.Tek == nil then Achievements.Tek = false end
	if Achievements.SkillIssue == nil then Achievements.SkillIssue = false end
	if Achievements.CoolSword == nil then Achievements.CoolSword = false end
end

MetalMod:AddCallback(ModCallbacks.MC_POST_PLAYER_INIT, MetalMod.onStart)

function MetalMod.onExit(save)
	MetalMod:SaveData(json.encode(Achievements))
end

MetalMod:AddCallback(ModCallbacks.MC_PRE_GAME_EXIT, MetalMod.onExit)
MetalMod:AddCallback(ModCallbacks.MC_POST_GAME_END, MetalMod.onExit)

function MetalMod:OnCommand(command, args)
	if command == "MetalReset" then
		print("Removed All Achievements")
		Achievements.CollectorsCoin = false
		Achievements.BanHammer = false
		Achievements.ChemicalX = false
		Achievements.ReverseCard = false
		Achievements.UwUCard = false
		
		Achievements.BIGNUT = false
		Achievements.Tek = false
		Achievements.SkillIssue = false
		Achievements.CoolSword = false
	elseif command == "MetalUnlock" then
		print("Unlocked All Achievements")
		Achievements.CollectorsCoin = true
		Achievements.BanHammer = true
		Achievements.ChemicalX = true
		Achievements.ReverseCard = true
		Achievements.UwUCard = true
		Achievements.BIGNUT = true
		Achievements.Tek = true
		Achievements.SkillIssue = true
		Achievements.CoolSword = true
	elseif command == "AchievementStates" then
		print("Achievement States")
		print(Achievements.CollectorsCoin)
		print(Achievements.BanHammer)
		print(Achievements.ChemicalX)
		print(Achievements.ReverseCard)
		print(Achievements.UwUCard)
		print(Achievements.BIGNUT)
		print(Achievements.Tek)
		print(Achievements.SkillIssue)
		print(Achievements.CoolSword)
    end
end
MetalMod:AddCallback(ModCallbacks.MC_EXECUTE_CMD, MetalMod.OnCommand)


-- Unlocks
function MetalMod.onMomDie()
	for playerNum = 1, Game():GetNumPlayers() do
		local player = Game():GetPlayer(playerNum)
		local game = Game()
		if player:GetName() == "Metal" then
			if Achievements.CollectorsCoin == false then
				Achievements.CollectorsCoin = true
				Game():GetHUD():ShowFortuneText("Collectors Coin Has Appeared In The Basement.")
			end
		end
		if player:GetName() == "Tainted Metal" then
			if Achievements.BIGNUT == false then
				Achievements.BIGNUT = true
				Game():GetHUD():ShowFortuneText("BIG NUT Has Appeared In The Basement.")
			end
		end
	end
end
MetalMod:AddCallback(ModCallbacks.MC_POST_ENTITY_KILL, MetalMod.onMomDie, EntityType.ENTITY_MOM)

function MetalMod.onMegaSatanDie()
	for playerNum = 1, Game():GetNumPlayers() do
		local player = Game():GetPlayer(playerNum)
		local game = Game()
		if player:GetName() == "Metal" then
			if Achievements.BanHammer == false then
				Achievements.BanHammer = true
				Game():GetHUD():ShowFortuneText("The Ban Hammer Has Appeared In The Basement.")
			end
		end
		if player:GetName() == "Tainted Metal" then
			if Achievements.CoolSword == false then
				Achievements.CoolSword = true
				Game():GetHUD():ShowFortuneText("Really Cool Sword Has Appeared In The Basement.")
			end
		end
	end
end
MetalMod:AddCallback(ModCallbacks.MC_POST_ENTITY_KILL, MetalMod.onMegaSatanDie, EntityType.ENTITY_MEGA_SATAN_2)

function MetalMod.onIsaacDie()
	for playerNum = 1, Game():GetNumPlayers() do
		local player = Game():GetPlayer(playerNum)
		local game = Game()
		if player:GetName() == "Metal" then
			if Achievements.ReverseCard == false then
				Achievements.ReverseCard = true
				Game():GetHUD():ShowFortuneText("Reverse Card Has Appeared In The Basement.")
			end
		end
		if player:GetName() == "Tainted Metal" then
			if Achievements.Tek == false then
				Achievements.Tek = true
				Game():GetHUD():ShowFortuneText("Tek The Modern Caveboy Has Appeared In The Basement.")
			end
		end
	end
end


MetalMod:AddCallback(ModCallbacks.MC_POST_ENTITY_KILL, MetalMod.onIsaacDie, EntityType.ENTITY_ISAAC)

function MetalMod.onSatanDie()
	for playerNum = 1, Game():GetNumPlayers() do
		local player = Game():GetPlayer(playerNum)
		local game = Game()
		if player:GetName() == "Metal" then
			if Achievements.UwUCard == false then
				Achievements.UwUCard = true
				Game():GetHUD():ShowFortuneText("UwU Card Has Appeared In The Basement.")
			end
		end
		if player:GetName() == "Tainted Metal" then
			if Achievements.SkillIssue == false then
				Achievements.SkillIssue = true
				Game():GetHUD():ShowFortuneText("Skill Issue Has Appeared In The Basement.")
			end
		end
	end
end

MetalMod:AddCallback(ModCallbacks.MC_POST_ENTITY_KILL, MetalMod.onIsaacDie, EntityType.ENTITY_SATAN)

function MetalMod.on5SoulHearts()
	for playerNum = 1, Game():GetNumPlayers() do
		local player = Game():GetPlayer(playerNum)
		local game = Game()
		if player:GetName() == "Metal" then
			if Achievements.ChemicalX == false then
				if player:GetSoulHearts() >= 10 then
					Achievements.ChemicalX = true
					Game():GetHUD():ShowFortuneText("Chemical X Has Appeared In The Basement.")
				end
			end
		end
	end
end
MetalMod:AddCallback(ModCallbacks.MC_POST_UPDATE,MetalMod.on5SoulHearts)


-- If Not Unlocked, Remove

local collectors_coin_item = Isaac.GetItemIdByName("Collector's Coin")
local big_nut_item = Isaac.GetItemIdByName("BIG NUT")
local tek_item = Isaac.GetItemIdByName("Tek The Modern Caveboy")
local skill_issue_item = Isaac.GetItemIdByName("Skill Issue")
local cool_sword_item = Isaac.GetItemIdByName("Really Cool Sword")

function MetalMod.AchieveCheck()
	for playerNum = 1, Game():GetNumPlayers() do
		local player = Game():GetPlayer(playerNum)
		local game = Game()
		if Achievements.CollectorsCoin == false then
			local room = Game():GetRoom()
			local entCoin = Isaac.FindByType(5, 100, collectors_coin_item)
			for i=1, #entCoin do
				local posCoin = entCoin[i].Position
				entCoin[i]:Remove()
				if room:GetType() ~= RoomType.ROOM_SHOP and room:GetType() ~= RoomType.ROOM_DEVIL then
					Isaac.Spawn(5, 100, 0, posCoin, Vector(0,0), player)
				end
				entCoin[i]:Remove()
				if room:GetType() == RoomType.ROOM_DEVIL then
					entCoin[i]:Remove()
					local spawnItem = Isaac.Spawn(5,100,0, posCoin, Vector(0,0), nil):ToPickup()
					spawnItem.Price = -1
					spawnItem.AutoUpdatePrice = false
					local data = spawnItem:GetData()
					data.Price = -1
					data.AutoUpdatePrice = false
				end
				entCoin[i]:Remove()
				if room:GetType() == RoomType.ROOM_SHOP then
					local spawnItem = Isaac.Spawn(5,100,0, posCoin, Vector(0,0), nil):ToPickup()
					spawnItem.Price = 15
					spawnItem.AutoUpdatePrice = false
					local data = spawnItem:GetData()
					data.Price = 15
					data.AutoUpdatePrice = false
				end
			end
		end
		-- 2nd item
		if Achievements.BIGNUT == false then
			local room = Game():GetRoom()
			local entBigNut = Isaac.FindByType(5, 100, big_nut_item)
			for i=1, #entBigNut do
				local posBigNut = entBigNut[i].Position
				entBigNut[i]:Remove()
				if room:GetType() ~= RoomType.ROOM_SHOP and room:GetType() ~= RoomType.ROOM_DEVIL then
					Isaac.Spawn(5, 100, 0, posBigNut, Vector(0,0), player)
				end
				entBigNut[i]:Remove()
				if room:GetType() == RoomType.ROOM_DEVIL then
					entBigNut[i]:Remove()
					local spawnItem = Isaac.Spawn(5,100,0, posBigNut, Vector(0,0), nil):ToPickup()
					spawnItem.Price = -1
					spawnItem.AutoUpdatePrice = false
					local data = spawnItem:GetData()
					data.Price = -1
					data.AutoUpdatePrice = false
				end
				entBigNut[i]:Remove()
				if room:GetType() == RoomType.ROOM_SHOP then
					local spawnItem = Isaac.Spawn(5,100,0, posBigNut, Vector(0,0), nil):ToPickup()
					spawnItem.Price = 15
					spawnItem.AutoUpdatePrice = false
					local data = spawnItem:GetData()
					data.Price = 15
					data.AutoUpdatePrice = false
				end
			end
		end
		-- 3nd item
		if Achievements.Tek == false then
			local room = Game():GetRoom()
			local entTek = Isaac.FindByType(5, 100, tek_item)
			for i=1, #entTek do
				local posTek = entTek[i].Position
				entTek[i]:Remove()
				if room:GetType() ~= RoomType.ROOM_SHOP and room:GetType() ~= RoomType.ROOM_DEVIL then
					Isaac.Spawn(5, 100, 0, posTek, Vector(0,0), player)
				end
				entTek[i]:Remove()
				if room:GetType() == RoomType.ROOM_DEVIL then
					entTek[i]:Remove()
					local spawnItem = Isaac.Spawn(5,100,0, posTek, Vector(0,0), nil):ToPickup()
					spawnItem.Price = -1
					spawnItem.AutoUpdatePrice = false
					local data = spawnItem:GetData()
					data.Price = -1
					data.AutoUpdatePrice = false
				end
				entTek[i]:Remove()
				if room:GetType() == RoomType.ROOM_SHOP then
					local spawnItem = Isaac.Spawn(5,100,0, posTek, Vector(0,0), nil):ToPickup()
					spawnItem.Price = 15
					spawnItem.AutoUpdatePrice = false
					local data = spawnItem:GetData()
					data.Price = 15
					data.AutoUpdatePrice = false
				end
			end
		end
		-- 4nd item
		if Achievements.SkillIssue == false then
			local room = Game():GetRoom()
			local entSkillIssue = Isaac.FindByType(5, 100, skill_issue_item)
			for i=1, #entSkillIssue do
				local posSkillIssue = entSkillIssue[i].Position
				entSkillIssue[i]:Remove()
				if room:GetType() ~= RoomType.ROOM_SHOP and room:GetType() ~= RoomType.ROOM_DEVIL then
					Isaac.Spawn(5, 100, 0, posSkillIssue, Vector(0,0), player)
				end
				entSkillIssue[i]:Remove()
				if room:GetType() == RoomType.ROOM_DEVIL then
					entSkillIssue[i]:Remove()
					local spawnItem = Isaac.Spawn(5,100,0, posSkillIssue, Vector(0,0), nil):ToPickup()
					spawnItem.Price = -1
					spawnItem.AutoUpdatePrice = false
					local data = spawnItem:GetData()
					data.Price = -1
					data.AutoUpdatePrice = false
				end
				entSkillIssue[i]:Remove()
				if room:GetType() == RoomType.ROOM_SHOP then
					local spawnItem = Isaac.Spawn(5,100,0, posSkillIssue, Vector(0,0), nil):ToPickup()
					spawnItem.Price = 15
					spawnItem.AutoUpdatePrice = false
					local data = spawnItem:GetData()
					data.Price = 15
					data.AutoUpdatePrice = false
				end
			end
		end
		-- 5nd item
		if Achievements.CoolSword == false then
			local room = Game():GetRoom()
			local entSword = Isaac.FindByType(5, 100, cool_sword_item)
			for i=1, #entSword do
				local posSword = entSword[i].Position
				entSword[i]:Remove()
				if room:GetType() ~= RoomType.ROOM_SHOP and room:GetType() ~= RoomType.ROOM_DEVIL then
					Isaac.Spawn(5, 100, 0, posSword, Vector(0,0), player)
				end
				entSword[i]:Remove()
				if room:GetType() == RoomType.ROOM_DEVIL then
					entSword[i]:Remove()
					local spawnItem = Isaac.Spawn(5,100,0, posSword, Vector(0,0), nil):ToPickup()
					spawnItem.Price = -1
					spawnItem.AutoUpdatePrice = false
					local data = spawnItem:GetData()
					data.Price = -1
					data.AutoUpdatePrice = false
				end
				entSword[i]:Remove()
				if room:GetType() == RoomType.ROOM_SHOP then
					local spawnItem = Isaac.Spawn(5,100,0, posSword, Vector(0,0), nil):ToPickup()
					spawnItem.Price = 15
					spawnItem.AutoUpdatePrice = false
					local data = spawnItem:GetData()
					data.Price = 15
					data.AutoUpdatePrice = false
				end
			end
		end
	end
end
MetalMod:AddCallback(ModCallbacks.MC_POST_UPDATE,MetalMod.AchieveCheck)

local ban_hammer_item = Isaac.GetItemIdByName("Ban Hammer")

function MetalMod.AchieveCheck2()
	for playerNum = 1, Game():GetNumPlayers() do
		local player = Game():GetPlayer(playerNum)
		local game = Game()
		if Achievements.BanHammer == false then
			local room = Game():GetRoom()
			local entHammer = Isaac.FindByType(5, 100, ban_hammer_item)
			for i=1, #entHammer do
				local posHammer = entHammer[i].Position
				entHammer[i]:Remove()
				if room:GetType() ~= RoomType.ROOM_SHOP and room:GetType() ~= RoomType.ROOM_DEVIL then
					Isaac.Spawn(5, 100, 0, posHammer, Vector(0,0), player)
				end
				entHammer[i]:Remove()
				if room:GetType() == RoomType.ROOM_DEVIL then
					entHammer[i]:Remove()
					local spawnItem = Isaac.Spawn(5,100,0, posHammer, Vector(0,0), nil):ToPickup()
					spawnItem.Price = -1
					spawnItem.AutoUpdatePrice = false
					local data = spawnItem:GetData()
					data.Price = -1
					data.AutoUpdatePrice = false
				end
				entHammer[i]:Remove()
				if room:GetType() == RoomType.ROOM_SHOP then
					local spawnItem = Isaac.Spawn(5,100,0, posHammer, Vector(0,0), nil):ToPickup()
					spawnItem.Price = 15
					spawnItem.AutoUpdatePrice = false
					local data = spawnItem:GetData()
					data.Price = 15
					data.AutoUpdatePrice = false
				end
			end
		end
	end
end
MetalMod:AddCallback(ModCallbacks.MC_POST_UPDATE,MetalMod.AchieveCheck2)

local chemical_x_item = Isaac.GetItemIdByName("Chemical X")

function MetalMod.AchieveCheck3()
	for playerNum = 1, Game():GetNumPlayers() do
		local player = Game():GetPlayer(playerNum)
		local game = Game()
		if Achievements.ChemicalX == false then
			local room = Game():GetRoom()
			local entChem = Isaac.FindByType(5, 100, chemical_x_item)
			for i=1, #entChem do
				local posChem = entChem[i].Position
				entChem[i]:Remove()
				if room:GetType() ~= RoomType.ROOM_SHOP and room:GetType() ~= RoomType.ROOM_DEVIL then
					Isaac.Spawn(5, 100, 0, posChem, Vector(0,0), player)
				end
				entChem[i]:Remove()
				if room:GetType() == RoomType.ROOM_DEVIL then
					entChem[i]:Remove()
					local spawnItem = Isaac.Spawn(5,100,0, posChem, Vector(0,0), nil):ToPickup()
					spawnItem.Price = -1
					spawnItem.AutoUpdatePrice = false
					local data = spawnItem:GetData()
					data.Price = -1
					data.AutoUpdatePrice = false
				end
				entChem[i]:Remove()
				if room:GetType() == RoomType.ROOM_SHOP then
					local spawnItem = Isaac.Spawn(5,100,0, posChem, Vector(0,0), nil):ToPickup()
					spawnItem.Price = 15
					spawnItem.AutoUpdatePrice = false
					local data = spawnItem:GetData()
					data.Price = 15
					data.AutoUpdatePrice = false
				end
			end
		end
	end
end
MetalMod:AddCallback(ModCallbacks.MC_POST_UPDATE,MetalMod.AchieveCheck3)

local reverse_card_item = Isaac.GetItemIdByName("Reverse Card")

function MetalMod.AchieveCheck4()
	for playerNum = 1, Game():GetNumPlayers() do
		local player = Game():GetPlayer(playerNum)
		local game = Game()
		if Achievements.ReverseCard == false then
			local room = Game():GetRoom()
			local entReverse = Isaac.FindByType(5, 100, reverse_card_item)
			for i=1, #entReverse do
				local posReverse = entReverse[i].Position
				entReverse[i]:Remove()
				if room:GetType() ~= RoomType.ROOM_SHOP and room:GetType() ~= RoomType.ROOM_DEVIL then
					Isaac.Spawn(5, 100, 0, posReverse, Vector(0,0), player)
				end
				entReverse[i]:Remove()
				if room:GetType() == RoomType.ROOM_DEVIL then
					entReverse[i]:Remove()
					local spawnItem = Isaac.Spawn(5,100,0, posReverse, Vector(0,0), nil):ToPickup()
					spawnItem.Price = -1
					spawnItem.AutoUpdatePrice = false
					local data = spawnItem:GetData()
					data.Price = -1
					data.AutoUpdatePrice = false
				end
				entReverse[i]:Remove()
				if room:GetType() == RoomType.ROOM_SHOP then
					local spawnItem = Isaac.Spawn(5,100,0, posReverse, Vector(0,0), nil):ToPickup()
					spawnItem.Price = 15
					spawnItem.AutoUpdatePrice = false
					local data = spawnItem:GetData()
					data.Price = 15
					data.AutoUpdatePrice = false
				end
			end
		end
	end
end
MetalMod:AddCallback(ModCallbacks.MC_POST_UPDATE,MetalMod.AchieveCheck4)

local uwu_card_item = Isaac.GetItemIdByName("UwU Card")

function MetalMod.AchieveCheck5()
	for playerNum = 1, Game():GetNumPlayers() do
		local player = Game():GetPlayer(playerNum)
		local game = Game()
		if Achievements.UwUCard == false then
			local room = Game():GetRoom()
			local entUwU = Isaac.FindByType(5, 100, uwu_card_item)
			for i=1, #entUwU do
				local posUwU = entUwU[i].Position
				entUwU[i]:Remove()
				if room:GetType() ~= RoomType.ROOM_SHOP and room:GetType() ~= RoomType.ROOM_DEVIL then
					Isaac.Spawn(5, 100, 0, posUwU, Vector(0,0), player)
				end
				entUwU[i]:Remove()
				if room:GetType() == RoomType.ROOM_DEVIL then
					entUwU[i]:Remove()
					local spawnItem = Isaac.Spawn(5,100,0, posUwU, Vector(0,0), nil):ToPickup()
					spawnItem.Price = -1
					spawnItem.AutoUpdatePrice = false
					local data = spawnItem:GetData()
					data.Price = -1
					data.AutoUpdatePrice = false
				end
				entUwU[i]:Remove()
				if room:GetType() == RoomType.ROOM_SHOP then
					local spawnItem = Isaac.Spawn(5,100,0, posUwU, Vector(0,0), nil):ToPickup()
					spawnItem.Price = 15
					spawnItem.AutoUpdatePrice = false
					local data = spawnItem:GetData()
					data.Price = 15
					data.AutoUpdatePrice = false
				end
			end
		end
	end
end
MetalMod:AddCallback(ModCallbacks.MC_POST_UPDATE,MetalMod.AchieveCheck5)




 -- else
local IsDead = {
	Yes = 0
}

function MetalMod:onCache(player, cacheFlag)
	if player:GetName() == "Metal" then
		if cacheFlag == CacheFlag.CACHE_DAMAGE then
			player.Damage = player.Damage + 0.7
		end
		if cacheFlag == CacheFlag.CACHE_FIREDELAY then
			player.MaxFireDelay = player.MaxFireDelay + 1.5
		end
		if cacheFlag == CacheFlag.CACHE_RANGE then
			player.TearRange = player.TearRange - 175
		end
	end
	if player:GetName() == "Tainted Metal" then
		if cacheFlag == CacheFlag.CACHE_DAMAGE then
			player.Damage = player.Damage - 0.75
		end
		if cacheFlag == CacheFlag.CACHE_FIREDELAY then
			player.MaxFireDelay = player.MaxFireDelay - 2.3
		end
		if cacheFlag == CacheFlag.CACHE_RANGE then
			player.TearRange = player.TearRange - 175
		end
	end
end

local MetalChar = Isaac.GetPlayerTypeByName("Metal");

function MetalMod:MC_POST_NEW_LEVEL()
	local player = Isaac.GetPlayer(0)
	local room = Game():GetRoom()
	if Game():GetLevel():GetStage() == 1 then
		local mycostume = Isaac.GetCostumeIdByPath("gfx/characters/Metal_Hair.anm2")
		if player:GetName() == "Metal" then
			IsDead.Yes = 0
			if player:GetPlayerType() == MetalChar then
				player:AddNullCostume(mycostume)
			end
			player:SetPocketActiveItem(Isaac.GetItemIdByName("Metal D6"), ActiveSlot.SLOT_POCKET, false)
		end
		if player:GetName() == "Tainted Metal" then
			player:AddNullCostume(mycostume)
			player:SetPocketActiveItem(Isaac.GetItemIdByName("Mystery Dice"), ActiveSlot.SLOT_POCKET, false)
		end
	end
end

function MetalMod.onDamage(mod,damaged_entity,damage_amount,damage_flags,damage_source,damage_countdown_frames)	
	local player = damaged_entity:ToPlayer()
	if player:GetName() == "Tainted Metal"
	or player:GetName() == "Metal" then
		if not damage_source 
		or damage_source.EntityType == EntityType.ENTITY_PLAYER
		or damage_source.EntityType == EntityType.ENTITY_PICKUP
		or damage_source.EntityType == EntityType.ENTITY_SLOT
		or damage_source.EntityType == EntityType.ENTITY_SLOT
		or (damage_flags & DamageFlag.DAMAGE_CURSED_DOOR) == DamageFlag.DAMAGE_CURSED_DOOR
		or (damage_flags & DamageFlag.DAMAGE_SPIKES) == DamageFlag.DAMAGE_SPIKES
		or (damage_flags & DamageFlag.DAMAGE_RED_HEARTS) == DamageFlag.DAMAGE_RED_HEARTS
		or (damage_flags & DamageFlag.DAMAGE_CURSED_DOOR) == DamageFlag.DAMAGE_CURSED_DOOR
		or (damage_flags & DamageFlag.DAMAGE_NO_PENALTIES) == DamageFlag.DAMAGE_NO_PENALTIES
		or (damage_flags & DamageFlag.DAMAGE_DEVIL) == DamageFlag.DAMAGE_DEVIL then return nil end
	
	
		Game():GetHUD():ShowItemText("Skill Issue.")
	end
end



function MetalMod.onDeath()
	for playerNum = 1, Game():GetNumPlayers() do
		local player = Game():GetPlayer(playerNum)
		local game = Game()
		if player:GetName() == "Metal" then
			if IsDead.Yes == 0 then
				player:Revive()
				player:AddMaxHearts(24)
				player:AddMaxHearts(-22)
				player:AddBlackHearts(6)
				player:AddMaxHearts(-2)
				player:AddBrokenHearts(9)
				Isaac.Spawn(5, 100, CollectibleType.COLLECTIBLE_MYSTERY_GIFT, Isaac.GetFreeNearPosition(Isaac.GetPlayer(0).Position,30), Vector(0,0), nil);
				Isaac.Spawn(5, 40, 2, Isaac.GetFreeNearPosition(Isaac.GetPlayer(0).Position,30), Vector(0,0), nil);
				Isaac.Spawn(5, 30, 3, Isaac.GetFreeNearPosition(Isaac.GetPlayer(0).Position,30), Vector(0,0), nil);
				Isaac.Spawn(5, 20, 2, Isaac.GetFreeNearPosition(Isaac.GetPlayer(0).Position,30), Vector(0,0), nil);
				Game():GetHUD():ShowFortuneText("Dont die again.")
				
				IsDead.Yes = 1
			end
		end
	end
end

function MetalMod.onUpdate()
	for playerNum = 1, Game():GetNumPlayers() do
		local player = Game():GetPlayer(playerNum)
		local game = Game()
		if player:GetName() == "Metal" then
			local room = Game():GetRoom()
			local ent = Isaac.FindByType(1000, 14)
			for i=1, #ent do
				local pos = ent[i].Position
				Isaac.Spawn(1000, 44, 0, pos, Vector(0,0), player)
			end
		end
		if player:GetName() == "Tainted Metal" then
			local room = Game():GetRoom()
			local ent = Isaac.FindByType(1000, 14)
			for i=1, #ent do
				local pos = ent[i].Position
				Isaac.Spawn(1000, 46, 0, pos, Vector(0,0), player)
			end
		end
	end
end


function MetalMod.onFireTear(_, tear)
	for playerNum = 1, Game():GetNumPlayers() do
		local player = Game():GetPlayer(playerNum)
		local game = Game()
		if player:GetName() == "Metal" then
			tear.TearFlags = tear.TearFlags | TearFlags.TEAR_HYDROBOUNCE
		end
		if player:GetName() == "Tainted Metal" then
			tear:ChangeVariant(TearVariant.BLOOD)
			tear.TearFlags = tear.TearFlags | TearFlags.TEAR_HYDROBOUNCE
		end
	end
end

MetalMod:AddCallback(ModCallbacks.MC_POST_FIRE_TEAR, MetalMod.onFireTear)

function MetalMod:update()
	local entities = Isaac.GetRoomEntities()
	for i = 1, #entities do
		local e = entities[i]
		if e.Type == 5 and e.Variant == 100 and e.SubType == 0 then
			e:Remove()
		end
	end
end

MetalMod:AddCallback(ModCallbacks.MC_POST_UPDATE , MetalMod.update);

local MetalD6Id = {
	Isaac.GetItemIdByName("Metal D6")
}

function MetalMod:use_MetalMod(itemUsed)
	if itemUsed == MetalD6Id[1] then
		local player = Isaac.GetPlayer(0)
		if player == nil then return false end
		local room = Game():GetRoom()
		if room:GetType() ~= RoomType.ROOM_SHOP
		and room:GetType() ~= RoomType.ROOM_DEVIL then
			local ent = Isaac.FindByType(5, 100, -1)
			for i=1, #ent do
				local pos = ent[i].Position
				ent[i]:Remove()
				Isaac.Spawn(5,100,CollectibleType.COLLECTIBLE_IRON_BAR, pos, Vector(0,0), player)
			end
		end
		if room:GetType() == RoomType.ROOM_SHOP then
			local ent2 = Isaac.FindByType(5, 100, -1)
			for i=1, #ent2 do
				local pos2 = ent2[i].Position
				ent2[i]:Remove()
				local spawnItem = Isaac.Spawn(5, 100, CollectibleType.COLLECTIBLE_IRON_BAR, pos2,Vector(0,0), player):ToPickup()
				spawnItem.Price = 15
				spawnItem.AutoUpdatePrice = false
				local data = spawnItem:GetData()
				data.Price = 15
			end
		end
		if room:GetType() == RoomType.ROOM_DEVIL then
			local ent2 = Isaac.FindByType(5, 100, -1)
			for i=1, #ent2 do
				local pos2 = ent2[i].Position
				ent2[i]:Remove()
				local spawnItem = Isaac.Spawn(5, 100, CollectibleType.COLLECTIBLE_IRON_BAR, pos2,Vector(0,0), player):ToPickup()
				spawnItem.Price = -1
				spawnItem.AutoUpdatePrice = false
				local data = spawnItem:GetData()
				data.Price = -1
			end
		end
		return {
		ShowAnim = true
		}
	end
end
MetalMod:AddCallback( ModCallbacks.MC_USE_ITEM, MetalMod.use_MetalMod );

MetalMod:AddCallback(ModCallbacks.MC_POST_UPDATE,MetalMod.onUpdate)
MetalMod:AddCallback(ModCallbacks.MC_POST_ENTITY_KILL, MetalMod.onDeath, EntityType.ENTITY_PLAYER)
MetalMod:AddCallback(ModCallbacks.MC_ENTITY_TAKE_DMG,MetalMod.onDamage, EntityType.ENTITY_PLAYER)
MetalMod:AddCallback(ModCallbacks.MC_POST_NEW_LEVEL, MetalMod.MC_POST_NEW_LEVEL)
MetalMod:AddCallback(ModCallbacks.MC_EVALUATE_CACHE, MetalMod.onCache)

local MysteryDiceId = {
	Isaac.GetItemIdByName("Mystery Dice")
}

local common_mystery2 = Isaac.GetItemIdByName("Common Mystery")
local rare_mystery2 = Isaac.GetItemIdByName("Rare Mystery")
local legendary_mystery2 = Isaac.GetItemIdByName("Legendary Mystery")

function MetalMod:use_MetalMod(itemUsed)
	if itemUsed == MysteryDiceId[1] then
		local player = Isaac.GetPlayer(0)
		if player == nil then return false end
		local room = Game():GetRoom()
		
		local MysteryDo = math.random(1,5)
		
		if MysteryDo == 1 then
			player:UseActiveItem(CollectibleType.COLLECTIBLE_D6)
			player:AddBoneHearts(2)
		elseif MysteryDo == 2 then
			player:UseActiveItem(CollectibleType.COLLECTIBLE_D6)
			player:UsePill(math.random(0,49),1)
		elseif MysteryDo == 3 then
			player:UseActiveItem(CollectibleType.COLLECTIBLE_D6)
			player:UseCard(math.random(0,97))
		elseif MysteryDo == 4 then
			player:UseActiveItem(CollectibleType.COLLECTIBLE_D6)
			player:AddSoulHearts(4)
		elseif MysteryDo == 5 then
			player:UseActiveItem(CollectibleType.COLLECTIBLE_D6)
			player:AddFriendlyDip(math.random(0,6),Isaac.GetFreeNearPosition(Isaac.GetPlayer(0).Position,30))
			player:AddFriendlyDip(math.random(0,6),Isaac.GetFreeNearPosition(Isaac.GetPlayer(0).Position,30))
			player:AddFriendlyDip(math.random(0,6),Isaac.GetFreeNearPosition(Isaac.GetPlayer(0).Position,30))
			player:AddFriendlyDip(math.random(0,6),Isaac.GetFreeNearPosition(Isaac.GetPlayer(0).Position,30))
			player:AddFriendlyDip(math.random(0,6),Isaac.GetFreeNearPosition(Isaac.GetPlayer(0).Position,30))
		end
		
		return {
		ShowAnim = true
		}
	end
end
MetalMod:AddCallback( ModCallbacks.MC_USE_ITEM, MetalMod.use_MetalMod );

local UwuCardId = {
	Isaac.GetItemIdByName("UwU Card")
}

function MetalMod:use_MetalMod(itemUsed)
	if itemUsed == UwuCardId[1] then
		local player = Isaac.GetPlayer(0)
		if player == nil then return false end
		local room = Game():GetRoom()
		if room:GetType() ~= RoomType.ROOM_BOSS then
			local entities = Isaac.GetRoomEntities()
			for i = 1, #entities do
				local entUwU = entities[i]
				entUwU:AddCharmed(EntityRef(player), -1)
			end
		else
			return {
			Discharge = false
			}
		end
		return {
		ShowAnim = true
		}
	end
end
MetalMod:AddCallback( ModCallbacks.MC_USE_ITEM, MetalMod.use_MetalMod );

local ReverseCardId = {
	Isaac.GetItemIdByName("Reverse Card")
}

function MetalMod:use_MetalMod(itemUsed)
	if itemUsed == ReverseCardId[1] then
		local player = Isaac.GetPlayer(0)
		if player == nil then return false end
		local room = Game():GetRoom()
		player:UseCard(math.random(56,77))
		return {
		ShowAnim = true
		}
	end
end
MetalMod:AddCallback( ModCallbacks.MC_USE_ITEM, MetalMod.use_MetalMod );

local TekId = {
	Isaac.GetItemIdByName("Tek The Modern Caveboy")
}

local tek_effect_item = Isaac.GetItemIdByName("Tek Effect")


function MetalMod:use_MetalMod(itemUsed)
	if itemUsed == TekId[1] then
		local player = Isaac.GetPlayer(0)
		if player == nil then return false end
		local room = Game():GetRoom()
		player:AddCollectible(tek_effect_item)
		return {
		ShowAnim = true
		}
	end
end
MetalMod:AddCallback( ModCallbacks.MC_USE_ITEM, MetalMod.use_MetalMod );


-- Collectors Coin
local game = Game()

local MetalModId2 = {
	COLLECTORS_COIN = Isaac.GetItemIdByName("Collector's Coin")
}

local HasMetalMod2 = {
	MetalMod = false
}

local function UpdateMetalMod(player)
	MetalMod.HasMetalMod2 = player:HasCollectible(MetalModId2.COLLECTORS_COIN)
end

function MetalMod:onPlayerInit(player)
	UpdateMetalMod(player)
end

MetalMod:AddCallback(ModCallbacks.MC_POST_PLAYER_INIT, MetalMod.onPlayerInit)

function MetalMod:onUpdate(player)
	UpdateMetalMod(player)
end

MetalMod:AddCallback(ModCallbacks.MC_POST_PEFFECT_UPDATE, MetalMod.onUpdate)

function MetalMod:onCache(player, cacheFlag)
	if cacheFlag == CacheFlag.CACHE_DAMAGE then
		if player:HasCollectible(MetalModId2.COLLECTORS_COIN) and not HasMetalMod2.MetalMod then
			player.Damage = player.Damage + 0
		end
	end
	if cacheFlag == CacheFlag.CACHE_FIREDELAY then
		if player:HasCollectible(MetalModId2.COLLECTORS_COIN) and not HasMetalMod2.MetalMod then
			player.MaxFireDelay = player.MaxFireDelay - 0
		end
	end
	if cacheFlag == CacheFlag.CACHE_LUCK then
		if player:HasCollectible(MetalModId2.COLLECTORS_COIN) and not HasMetalMod2.MetalMod then
			player.Luck = player.Luck + 3
		end
	end
	if cacheFlag == CacheFlag.CACHE_SHOTSPEED then
		if player:HasCollectible(MetalModId2.COLLECTORS_COIN) and not HasMetalMod2.MetalMod then
			player.ShotSpeed = player.ShotSpeed + 0
		end
	end
	if cacheFlag == CacheFlag.CACHE_SPEED then
		if player:HasCollectible(MetalModId2.COLLECTORS_COIN) and not HasMetalMod2.MetalMod then
			player.MoveSpeed = player.MoveSpeed + 0
		end
	end
	if cacheFlag == CacheFlag.CACHE_RANGE then
		if player:HasCollectible(MetalModId2.COLLECTORS_COIN) and not HasMetalMod2.MetalMod then
			player.TearRange = player.TearRange + 0
		end
	end
end

MetalMod:AddCallback(ModCallbacks.MC_EVALUATE_CACHE, MetalMod.onCache)

MetalMod.COLLECTIBLE_COLLECTORS_COIN = Isaac.GetItemIdByName("Collector's Coin")

function MetalMod:onUpdate()
	-- begin
	if Game():GetFrameCount() == 1 then
		MetalMod.HasMetalMod2 = false
	end
	
	-- functionality
	for playerNum = 1, Game():GetNumPlayers() do
		local player = Game():GetPlayer(playerNum)
		if player:HasCollectible(MetalMod.COLLECTIBLE_COLLECTORS_COIN) then
			if not MetalMod.HasMetalMod2 then
				player:AddCoins(1)
				MetalMod.HasMetalMod2 = true
			end
		end
	end
end

MetalMod:AddCallback(ModCallbacks.MC_POST_UPDATE,MetalMod.onUpdate)

-- The Feet XD
local game = Game()

local MetalModId3 = {
	THE_FEET = Isaac.GetItemIdByName("The Feet")
}

local HasMetalMod3 = {
	MetalMod = false
}

local function UpdateMetalMod(player)
	MetalMod.HasMetalMod3 = player:HasCollectible(MetalModId3.THE_FEET)
end

function MetalMod:onPlayerInit(player)
	UpdateMetalMod(player)
end

MetalMod:AddCallback(ModCallbacks.MC_POST_PLAYER_INIT, MetalMod.onPlayerInit)

function MetalMod:onUpdate(player)
	UpdateMetalMod(player)
end

MetalMod:AddCallback(ModCallbacks.MC_POST_PEFFECT_UPDATE, MetalMod.onUpdate)

function MetalMod:onCache(player, cacheFlag)
	if cacheFlag == CacheFlag.CACHE_DAMAGE then
		if player:HasCollectible(MetalModId3.THE_FEET) and not HasMetalMod3.MetalMod then
			player.Damage = player.Damage + 0
		end
	end
	if cacheFlag == CacheFlag.CACHE_FIREDELAY then
		if player:HasCollectible(MetalModId3.THE_FEET) and not HasMetalMod3.MetalMod then
			player.MaxFireDelay = player.MaxFireDelay - 0
		end
	end
	if cacheFlag == CacheFlag.CACHE_LUCK then
		if player:HasCollectible(MetalModId3.THE_FEET) and not HasMetalMod3.MetalMod then
			player.Luck = player.Luck + 0
		end
	end
	if cacheFlag == CacheFlag.CACHE_SHOTSPEED then
		if player:HasCollectible(MetalModId3.THE_FEET) and not HasMetalMod3.MetalMod then
			player.ShotSpeed = player.ShotSpeed + 0
		end
	end
	if cacheFlag == CacheFlag.CACHE_SPEED then
		if player:HasCollectible(MetalModId3.THE_FEET) and not HasMetalMod3.MetalMod then
			player.MoveSpeed = player.MoveSpeed + 0.25
		end
	end
	if cacheFlag == CacheFlag.CACHE_RANGE then
		if player:HasCollectible(MetalModId3.THE_FEET) and not HasMetalMod3.MetalMod then
			player.TearRange = player.TearRange + 0
		end
	end
end

MetalMod:AddCallback(ModCallbacks.MC_EVALUATE_CACHE, MetalMod.onCache)

MetalMod.COLLECTIBLE_THE_FEET = Isaac.GetItemIdByName("The Feet")

function MetalMod:onUpdate()
	-- begin
	if Game():GetFrameCount() == 1 then
		MetalMod.HasMetalMod3 = false
	end
	
	-- functionality
	for playerNum = 1, Game():GetNumPlayers() do
		local player = Game():GetPlayer(playerNum)
		if player:HasCollectible(MetalMod.COLLECTIBLE_THE_FEET) then
			if not MetalMod.HasMetalMod3 then
				MetalMod.HasMetalMod3 = true
			end
		end
	end
end

MetalMod:AddCallback(ModCallbacks.MC_POST_UPDATE,MetalMod.onUpdate)

-- Chemical X
local game = Game()

local MetalModId4 = {
	CHEMICAL_X = Isaac.GetItemIdByName("Chemical X")
}

local HasMetalMod4 = {
	MetalMod = false
}

local function UpdateMetalMod(player)
	MetalMod.HasMetalMod4 = player:HasCollectible(MetalModId4.CHEMICAL_X)
end

function MetalMod:onPlayerInit(player)
	UpdateMetalMod(player)
end

MetalMod:AddCallback(ModCallbacks.MC_POST_PLAYER_INIT, MetalMod.onPlayerInit)

function MetalMod:onUpdate(player)
	UpdateMetalMod(player)
end

MetalMod:AddCallback(ModCallbacks.MC_POST_PEFFECT_UPDATE, MetalMod.onUpdate)

function MetalMod:onCache(player, cacheFlag)
	if cacheFlag == CacheFlag.CACHE_DAMAGE then
		if player:HasCollectible(MetalModId4.CHEMICAL_X) and not HasMetalMod4.MetalMod then
			player.Damage = player.Damage + 1.5
		end
	end
	if cacheFlag == CacheFlag.CACHE_FIREDELAY then
		if player:HasCollectible(MetalModId4.CHEMICAL_X) and not HasMetalMod4.MetalMod then
			player.MaxFireDelay = player.MaxFireDelay - 0
		end
	end
	if cacheFlag == CacheFlag.CACHE_LUCK then
		if player:HasCollectible(MetalModId4.CHEMICAL_X) and not HasMetalMod4.MetalMod then
			player.Luck = player.Luck + 0
		end
	end
	if cacheFlag == CacheFlag.CACHE_SHOTSPEED then
		if player:HasCollectible(MetalModId4.CHEMICAL_X) and not HasMetalMod4.MetalMod then
			player.ShotSpeed = player.ShotSpeed + 0
		end
	end
	if cacheFlag == CacheFlag.CACHE_SPEED then
		if player:HasCollectible(MetalModId4.CHEMICAL_X) and not HasMetalMod4.MetalMod then
			player.MoveSpeed = player.MoveSpeed + 0.10
		end
	end
	if cacheFlag == CacheFlag.CACHE_RANGE then
		if player:HasCollectible(MetalModId4.CHEMICAL_X) and not HasMetalMod4.MetalMod then
			player.TearRange = player.TearRange + 0
		end
	end
	if cacheFlag == CacheFlag.CACHE_FLYING then
		if player:HasCollectible(MetalModId4.CHEMICAL_X) and not HasMetalMod4.MetalMod then
			player.CanFly = true
		end
	end
end

MetalMod:AddCallback(ModCallbacks.MC_EVALUATE_CACHE, MetalMod.onCache)

MetalMod.COLLECTIBLE_CHEMICAL_X = Isaac.GetItemIdByName("Chemical X")

function MetalMod:onUpdate()
	-- begin
	if Game():GetFrameCount() == 1 then
		MetalMod.HasMetalMod4 = false
	end
	
	-- functionality
	for playerNum = 1, Game():GetNumPlayers() do
		local player = Game():GetPlayer(playerNum)
		if player:HasCollectible(MetalMod.COLLECTIBLE_CHEMICAL_X) then
			if not MetalMod.HasMetalMod4 then
				MetalMod.HasMetalMod4 = true
			end
		end
	end
end

MetalMod:AddCallback(ModCallbacks.MC_POST_UPDATE,MetalMod.onUpdate)

-- Ban Hammer
local game = Game()

local MetalModId5 = {
	BAN_HAMMER = Isaac.GetItemIdByName("Ban Hammer")
}

local HasMetalMod5 = {
	MetalMod = false
}

local function UpdateMetalMod(player)
	MetalMod.HasMetalMod5 = player:HasCollectible(MetalModId5.BAN_HAMMER)
end

function MetalMod:onPlayerInit(player)
	UpdateMetalMod(player)
end

MetalMod:AddCallback(ModCallbacks.MC_POST_PLAYER_INIT, MetalMod.onPlayerInit)

function MetalMod:onUpdate(player)
	UpdateMetalMod(player)
end

MetalMod:AddCallback(ModCallbacks.MC_POST_PEFFECT_UPDATE, MetalMod.onUpdate)

function MetalMod:onCache(player, cacheFlag)
	if cacheFlag == CacheFlag.CACHE_DAMAGE then
		if player:HasCollectible(MetalModId5.BAN_HAMMER) and not HasMetalMod5.MetalMod then
			player.Damage = player.Damage * 1.15
		end
	end
	if cacheFlag == CacheFlag.CACHE_FIREDELAY then
		if player:HasCollectible(MetalModId5.BAN_HAMMER) and not HasMetalMod5.MetalMod then
			player.MaxFireDelay = player.MaxFireDelay - 0
		end
	end
	if cacheFlag == CacheFlag.CACHE_LUCK then
		if player:HasCollectible(MetalModId5.BAN_HAMMER) and not HasMetalMod5.MetalMod then
			player.Luck = player.Luck + 0
		end
	end
	if cacheFlag == CacheFlag.CACHE_SHOTSPEED then
		if player:HasCollectible(MetalModId5.BAN_HAMMER) and not HasMetalMod5.MetalMod then
			player.ShotSpeed = player.ShotSpeed + 0
		end
	end
	if cacheFlag == CacheFlag.CACHE_SPEED then
		if player:HasCollectible(MetalModId5.BAN_HAMMER) and not HasMetalMod5.MetalMod then
			player.MoveSpeed = player.MoveSpeed + 0
		end
	end
	if cacheFlag == CacheFlag.CACHE_RANGE then
		if player:HasCollectible(MetalModId5.BAN_HAMMER) and not HasMetalMod5.MetalMod then
			player.TearRange = player.TearRange + 0
		end
	end
end

MetalMod:AddCallback(ModCallbacks.MC_EVALUATE_CACHE, MetalMod.onCache)

MetalMod.COLLECTIBLE_BAN_HAMMER = Isaac.GetItemIdByName("Ban Hammer")

function MetalMod:onUpdate()
	-- begin
	if Game():GetFrameCount() == 1 then
		MetalMod.HasMetalMod5 = false
	end
	
	-- functionality
	for playerNum = 1, Game():GetNumPlayers() do
		local player = Game():GetPlayer(playerNum)
		if player:HasCollectible(MetalMod.COLLECTIBLE_BAN_HAMMER) then
			if not MetalMod.HasMetalMod5 then
				MetalMod.HasMetalMod5 = true
			end
		end
	end
end

MetalMod:AddCallback(ModCallbacks.MC_POST_UPDATE,MetalMod.onUpdate)

-- Doctor Banana
local game = Game()

local MetalModId6 = {
	DOCTOR_BANANA = Isaac.GetItemIdByName("Dr. Banana")
}

local HasMetalMod6 = {
	MetalMod = false
}

local function UpdateMetalMod(player)
	MetalMod.HasMetalMod6 = player:HasCollectible(MetalModId6.DOCTOR_BANANA)
end

function MetalMod:onPlayerInit(player)
	UpdateMetalMod(player)
end

MetalMod:AddCallback(ModCallbacks.MC_POST_PLAYER_INIT, MetalMod.onPlayerInit)

function MetalMod:onUpdate(player)
	UpdateMetalMod(player)
end

MetalMod:AddCallback(ModCallbacks.MC_POST_PEFFECT_UPDATE, MetalMod.onUpdate)

function MetalMod:onCache(player, cacheFlag)
	if cacheFlag == CacheFlag.CACHE_DAMAGE then
		if player:HasCollectible(MetalModId6.DOCTOR_BANANA) and not HasMetalMod6.MetalMod then
			player.Damage = player.Damage * 1.25
		end
	end
	if cacheFlag == CacheFlag.CACHE_FIREDELAY then
		if player:HasCollectible(MetalModId6.DOCTOR_BANANA) and not HasMetalMod6.MetalMod then
			player.MaxFireDelay = player.MaxFireDelay - 1
		end
	end
	if cacheFlag == CacheFlag.CACHE_LUCK then
		if player:HasCollectible(MetalModId6.DOCTOR_BANANA) and not HasMetalMod6.MetalMod then
			player.Luck = player.Luck + 1
		end
	end
	if cacheFlag == CacheFlag.CACHE_SHOTSPEED then
		if player:HasCollectible(MetalModId6.DOCTOR_BANANA) and not HasMetalMod6.MetalMod then
			player.ShotSpeed = player.ShotSpeed + 0
		end
	end
	if cacheFlag == CacheFlag.CACHE_SPEED then
		if player:HasCollectible(MetalModId6.DOCTOR_BANANA) and not HasMetalMod6.MetalMod then
			player.MoveSpeed = player.MoveSpeed + 0.10
		end
	end
	if cacheFlag == CacheFlag.CACHE_RANGE then
		if player:HasCollectible(MetalModId6.DOCTOR_BANANA) and not HasMetalMod6.MetalMod then
			player.TearRange = player.TearRange + 0
		end
	end
end

MetalMod:AddCallback(ModCallbacks.MC_EVALUATE_CACHE, MetalMod.onCache)

MetalMod.COLLECTIBLE_DOCTOR_BANANA = Isaac.GetItemIdByName("Dr. Banana")

function MetalMod:onUpdate()
	-- begin
	if Game():GetFrameCount() == 1 then
		MetalMod.HasMetalMod6 = false
	end
	
	-- functionality
	for playerNum = 1, Game():GetNumPlayers() do
		local player = Game():GetPlayer(playerNum)
		if player:HasCollectible(MetalMod.COLLECTIBLE_DOCTOR_BANANA) then
			if not MetalMod.HasMetalMod6 then
				player:AddMaxHearts(2)
				player:AddHearts(4)
				player:AddSoulHearts(2)
				MetalMod.HasMetalMod6 = true
				
			end
		end
	end
end

MetalMod:AddCallback(ModCallbacks.MC_POST_UPDATE,MetalMod.onUpdate)

-- Banana's Degree
local game = Game()

local MetalModId10 = {
	BANANAS_DEGREE = Isaac.GetItemIdByName("Banana's Degree")
}

local HasMetalMod10 = {
	MetalMod = false
}

local function UpdateMetalMod(player)
	MetalMod.HasMetalMod10 = player:HasCollectible(MetalModId10.BANANAS_DEGREE)
end

function MetalMod:onPlayerInit(player)
	UpdateMetalMod(player)
end

MetalMod:AddCallback(ModCallbacks.MC_POST_PLAYER_INIT, MetalMod.onPlayerInit)

function MetalMod:onUpdate(player)
	UpdateMetalMod(player)
end

MetalMod:AddCallback(ModCallbacks.MC_POST_PEFFECT_UPDATE, MetalMod.onUpdate)

function MetalMod:onCache(player, cacheFlag)
	if cacheFlag == CacheFlag.CACHE_DAMAGE then
		if player:HasCollectible(MetalModId10.BANANAS_DEGREE) and not HasMetalMod10.MetalMod then
			player.Damage = player.Damage + 0
		end
	end
	if cacheFlag == CacheFlag.CACHE_FIREDELAY then
		if player:HasCollectible(MetalModId10.BANANAS_DEGREE) and not HasMetalMod10.MetalMod then
			player.MaxFireDelay = player.MaxFireDelay - 0
		end
	end
	if cacheFlag == CacheFlag.CACHE_LUCK then
		if player:HasCollectible(MetalModId10.BANANAS_DEGREE) and not HasMetalMod10.MetalMod then
			player.Luck = player.Luck + 1
		end
	end
	if cacheFlag == CacheFlag.CACHE_SHOTSPEED then
		if player:HasCollectible(MetalModId10.BANANAS_DEGREE) and not HasMetalMod10.MetalMod then
			player.ShotSpeed = player.ShotSpeed + 0
		end
	end
	if cacheFlag == CacheFlag.CACHE_SPEED then
		if player:HasCollectible(MetalModId10.BANANAS_DEGREE) and not HasMetalMod10.MetalMod then
			player.MoveSpeed = player.MoveSpeed + 0.10
		end
	end
	if cacheFlag == CacheFlag.CACHE_RANGE then
		if player:HasCollectible(MetalModId10.BANANAS_DEGREE) and not HasMetalMod10.MetalMod then
			player.TearRange = player.TearRange + 0
		end
	end
end

MetalMod:AddCallback(ModCallbacks.MC_EVALUATE_CACHE, MetalMod.onCache)

MetalMod.COLLECTIBLE_BANANAS_DEGREE = Isaac.GetItemIdByName("Banana's Degree")

function MetalMod:onUpdate()
	-- begin
	if Game():GetFrameCount() == 1 then
		MetalMod.HasMetalMod10 = false
	end
	
	-- functionality
	for playerNum = 1, Game():GetNumPlayers() do
		local player = Game():GetPlayer(playerNum)
		if player:HasCollectible(MetalMod.COLLECTIBLE_BANANAS_DEGREE) then
			if not MetalMod.HasMetalMod10 then
				player:AddMaxHearts(4)
				player:AddHearts(6)
				MetalMod.HasMetalMod10 = true
				
			end
		end
	end
end

MetalMod:AddCallback(ModCallbacks.MC_POST_UPDATE,MetalMod.onUpdate)

-- GamerThePokemon
local game = Game()

local MetalModId11 = {
	GAMERTHEPOKEMON = Isaac.GetItemIdByName("GamerThePokemon")
}

local HasMetalMod11 = {
	MetalMod = false
}

local function UpdateMetalMod(player)
	MetalMod.HasMetalMod11 = player:HasCollectible(MetalModId11.GAMERTHEPOKEMON)
end

function MetalMod:onPlayerInit(player)
	UpdateMetalMod(player)
end

MetalMod:AddCallback(ModCallbacks.MC_POST_PLAYER_INIT, MetalMod.onPlayerInit)

function MetalMod:onUpdate(player)
	UpdateMetalMod(player)
end

MetalMod:AddCallback(ModCallbacks.MC_POST_PEFFECT_UPDATE, MetalMod.onUpdate)

function MetalMod:onCache(player, cacheFlag)
	if cacheFlag == CacheFlag.CACHE_DAMAGE then
		if player:HasCollectible(MetalModId11.GAMERTHEPOKEMON) and not HasMetalMod11.MetalMod then
			player.Damage = player.Damage + 1
		end
	end
	if cacheFlag == CacheFlag.CACHE_FIREDELAY then
		if player:HasCollectible(MetalModId11.GAMERTHEPOKEMON) and not HasMetalMod11.MetalMod then
			player.MaxFireDelay = player.MaxFireDelay - 0
		end
	end
	if cacheFlag == CacheFlag.CACHE_LUCK then
		if player:HasCollectible(MetalModId11.GAMERTHEPOKEMON) and not HasMetalMod11.MetalMod then
			player.Luck = player.Luck + 0
		end
	end
	if cacheFlag == CacheFlag.CACHE_SHOTSPEED then
		if player:HasCollectible(MetalModId11.GAMERTHEPOKEMON) and not HasMetalMod11.MetalMod then
			player.ShotSpeed = player.ShotSpeed + 0
		end
	end
	if cacheFlag == CacheFlag.CACHE_SPEED then
		if player:HasCollectible(MetalModId11.GAMERTHEPOKEMON) and not HasMetalMod11.MetalMod then
			player.MoveSpeed = player.MoveSpeed + 0.20
		end
	end
	if cacheFlag == CacheFlag.CACHE_RANGE then
		if player:HasCollectible(MetalModId11.GAMERTHEPOKEMON) and not HasMetalMod11.MetalMod then
			player.TearRange = player.TearRange + 0
		end
	end
end

MetalMod:AddCallback(ModCallbacks.MC_EVALUATE_CACHE, MetalMod.onCache)

MetalMod.COLLECTIBLE_GAMERTHEPOKEMON = Isaac.GetItemIdByName("GamerThePokemon")

function MetalMod:onUpdate()
	-- begin
	if Game():GetFrameCount() == 1 then
		MetalMod.HasMetalMod11 = false
	end
	
	-- functionality
	for playerNum = 1, Game():GetNumPlayers() do
		local player = Game():GetPlayer(playerNum)
		if player:HasCollectible(MetalMod.COLLECTIBLE_GAMERTHEPOKEMON) then
			if not MetalMod.HasMetalMod11 then
				MetalMod.HasMetalMod11 = true
				
			end
		end
	end
end

MetalMod:AddCallback(ModCallbacks.MC_POST_UPDATE,MetalMod.onUpdate)

-- Bubbles Without Makeup
local game = Game()

local MetalModId12 = {
	BUBBLES_WITHOUT_MAKEUP = Isaac.GetItemIdByName("Bubbles Without Makeup")
}

local HasMetalMod12 = {
	MetalMod = false
}

local function UpdateMetalMod(player)
	MetalMod.HasMetalMod12 = player:HasCollectible(MetalModId12.BUBBLES_WITHOUT_MAKEUP)
end

function MetalMod:onPlayerInit(player)
	UpdateMetalMod(player)
end

MetalMod:AddCallback(ModCallbacks.MC_POST_PLAYER_INIT, MetalMod.onPlayerInit)

function MetalMod:onUpdate(player)
	UpdateMetalMod(player)
end

MetalMod:AddCallback(ModCallbacks.MC_POST_PEFFECT_UPDATE, MetalMod.onUpdate)

function MetalMod:onCache(player, cacheFlag)
	if cacheFlag == CacheFlag.CACHE_DAMAGE then
		if player:HasCollectible(MetalModId12.BUBBLES_WITHOUT_MAKEUP) and not HasMetalMod12.MetalMod then
			player.Damage = player.Damage - 1.15
		end
	end
	if cacheFlag == CacheFlag.CACHE_FIREDELAY then
		if player:HasCollectible(MetalModId12.BUBBLES_WITHOUT_MAKEUP) and not HasMetalMod12.MetalMod then
			player.MaxFireDelay = player.MaxFireDelay - 1.5
		end
	end
	if cacheFlag == CacheFlag.CACHE_LUCK then
		if player:HasCollectible(MetalModId12.BUBBLES_WITHOUT_MAKEUP) and not HasMetalMod12.MetalMod then
			player.Luck = player.Luck + 0
		end
	end
	if cacheFlag == CacheFlag.CACHE_SHOTSPEED then
		if player:HasCollectible(MetalModId12.BUBBLES_WITHOUT_MAKEUP) and not HasMetalMod12.MetalMod then
			player.ShotSpeed = player.ShotSpeed + 0
		end
	end
	if cacheFlag == CacheFlag.CACHE_SPEED then
		if player:HasCollectible(MetalModId12.BUBBLES_WITHOUT_MAKEUP) and not HasMetalMod12.MetalMod then
			player.MoveSpeed = player.MoveSpeed + 0
		end
	end
	if cacheFlag == CacheFlag.CACHE_RANGE then
		if player:HasCollectible(MetalModId12.BUBBLES_WITHOUT_MAKEUP) and not HasMetalMod12.MetalMod then
			player.TearRange = player.TearRange + 0
		end
	end
end

MetalMod:AddCallback(ModCallbacks.MC_EVALUATE_CACHE, MetalMod.onCache)

MetalMod.COLLECTIBLE_BUBBLES_WITHOUT_MAKEUP = Isaac.GetItemIdByName("Bubbles Without Makeup")

function MetalMod:onUpdate()
	-- begin
	if Game():GetFrameCount() == 1 then
		MetalMod.HasMetalMod12 = false
	end
	
	-- functionality
	for playerNum = 1, Game():GetNumPlayers() do
		local player = Game():GetPlayer(playerNum)
		if player:HasCollectible(MetalMod.COLLECTIBLE_BUBBLES_WITHOUT_MAKEUP) then
			if not MetalMod.HasMetalMod12 then
				player:AddSoulHearts(2)
				MetalMod.HasMetalMod12 = true
				
			end
		end
	end
end

MetalMod:AddCallback(ModCallbacks.MC_POST_UPDATE,MetalMod.onUpdate)

-- Sarced Heart XD
local game = Game()

local MetalModId13 = {
	SARCED_HEART = Isaac.GetItemIdByName("Sarced Heart")
}

local HasMetalMod13 = {
	MetalMod = false
}

local function UpdateMetalMod(player)
	MetalMod.HasMetalMod13 = player:HasCollectible(MetalModId13.SARCED_HEART)
end

function MetalMod:onPlayerInit(player)
	UpdateMetalMod(player)
end

MetalMod:AddCallback(ModCallbacks.MC_POST_PLAYER_INIT, MetalMod.onPlayerInit)

function MetalMod:onUpdate(player)
	UpdateMetalMod(player)
end

MetalMod:AddCallback(ModCallbacks.MC_POST_PEFFECT_UPDATE, MetalMod.onUpdate)

function MetalMod:onCache(player, cacheFlag)
	if cacheFlag == CacheFlag.CACHE_DAMAGE then
		if player:HasCollectible(MetalModId13.SARCED_HEART) and not HasMetalMod13.MetalMod then
			player.Damage = player.Damage * 0.75
		end
	end
	if cacheFlag == CacheFlag.CACHE_FIREDELAY then
		if player:HasCollectible(MetalModId13.SARCED_HEART) and not HasMetalMod13.MetalMod then
			player.MaxFireDelay = player.MaxFireDelay - 2.3
		end
	end
	if cacheFlag == CacheFlag.CACHE_LUCK then
		if player:HasCollectible(MetalModId13.SARCED_HEART) and not HasMetalMod13.MetalMod then
			player.Luck = player.Luck + -1
		end
	end
	if cacheFlag == CacheFlag.CACHE_SHOTSPEED then
		if player:HasCollectible(MetalModId13.SARCED_HEART) and not HasMetalMod13.MetalMod then
			player.ShotSpeed = player.ShotSpeed + 0
		end
	end
	if cacheFlag == CacheFlag.CACHE_SPEED then
		if player:HasCollectible(MetalModId13.SARCED_HEART) and not HasMetalMod13.MetalMod then
			player.MoveSpeed = player.MoveSpeed + 0.10
		end
	end
	if cacheFlag == CacheFlag.CACHE_RANGE then
		if player:HasCollectible(MetalModId13.SARCED_HEART) and not HasMetalMod13.MetalMod then
			player.TearRange = player.TearRange + 0
		end
	end
end

MetalMod:AddCallback(ModCallbacks.MC_EVALUATE_CACHE, MetalMod.onCache)

MetalMod.COLLECTIBLE_SARCED_HEART = Isaac.GetItemIdByName("Sarced Heart")

function MetalMod:onUpdate()
	-- begin
	if Game():GetFrameCount() == 1 then
		MetalMod.HasMetalMod13 = false
	end
	
	-- functionality
	for playerNum = 1, Game():GetNumPlayers() do
		local player = Game():GetPlayer(playerNum)
		if player:HasCollectible(MetalMod.COLLECTIBLE_SARCED_HEART) then
			if not MetalMod.HasMetalMod13 then
				player:AddMaxHearts(2)
				player:AddHearts(4)
				MetalMod.HasMetalMod13 = true
				
			end
		end
	end
end

MetalMod:AddCallback(ModCallbacks.MC_POST_UPDATE,MetalMod.onUpdate)

-- Hot Coco
local game = Game()

local MetalModId14 = {
	HOT_COCO = Isaac.GetItemIdByName("Hot Coco")
}

local HasMetalMod14 = {
	MetalMod = false
}

local function UpdateMetalMod(player)
	MetalMod.HasMetalMod14 = player:HasCollectible(MetalModId14.HOT_COCO)
end

function MetalMod:onPlayerInit(player)
	UpdateMetalMod(player)
end

MetalMod:AddCallback(ModCallbacks.MC_POST_PLAYER_INIT, MetalMod.onPlayerInit)

function MetalMod:onUpdate(player)
	UpdateMetalMod(player)
end

MetalMod:AddCallback(ModCallbacks.MC_POST_PEFFECT_UPDATE, MetalMod.onUpdate)

function MetalMod:onCache(player, cacheFlag)
	if cacheFlag == CacheFlag.CACHE_DAMAGE then
		if player:HasCollectible(MetalModId14.HOT_COCO) and not HasMetalMod14.MetalMod then
			player.Damage = player.Damage + 0
		end
	end
	if cacheFlag == CacheFlag.CACHE_FIREDELAY then
		if player:HasCollectible(MetalModId14.HOT_COCO) and not HasMetalMod14.MetalMod then
			player.MaxFireDelay = player.MaxFireDelay - 1.5
		end
	end
	if cacheFlag == CacheFlag.CACHE_LUCK then
		if player:HasCollectible(MetalModId14.HOT_COCO) and not HasMetalMod14.MetalMod then
			player.Luck = player.Luck + 0
		end
	end
	if cacheFlag == CacheFlag.CACHE_SHOTSPEED then
		if player:HasCollectible(MetalModId14.HOT_COCO) and not HasMetalMod14.MetalMod then
			player.ShotSpeed = player.ShotSpeed + 0
		end
	end
	if cacheFlag == CacheFlag.CACHE_SPEED then
		if player:HasCollectible(MetalModId14.HOT_COCO) and not HasMetalMod14.MetalMod then
			player.MoveSpeed = player.MoveSpeed + 0
		end
	end
	if cacheFlag == CacheFlag.CACHE_RANGE then
		if player:HasCollectible(MetalModId14.HOT_COCO) and not HasMetalMod14.MetalMod then
			player.TearRange = player.TearRange + 0
		end
	end
end

MetalMod:AddCallback(ModCallbacks.MC_EVALUATE_CACHE, MetalMod.onCache)

MetalMod.COLLECTIBLE_HOT_COCO = Isaac.GetItemIdByName("Hot Coco")

function MetalMod:onUpdate()
	-- begin
	if Game():GetFrameCount() == 1 then
		MetalMod.HasMetalMod14 = false
	end
	
	-- functionality
	for playerNum = 1, Game():GetNumPlayers() do
		local player = Game():GetPlayer(playerNum)
		if player:HasCollectible(MetalMod.COLLECTIBLE_HOT_COCO) then
			if not MetalMod.HasMetalMod14 then
				MetalMod.HasMetalMod14 = true
				
			end
		end
	end
end

MetalMod:AddCallback(ModCallbacks.MC_POST_UPDATE,MetalMod.onUpdate)

-- Doctor Banana
local game = Game()

local MetalModId15 = {
	GRANOLA_BAR = Isaac.GetItemIdByName("Granola Bar")
}

local HasMetalMod15 = {
	MetalMod = false
}

local function UpdateMetalMod(player)
	MetalMod.HasMetalMod15 = player:HasCollectible(MetalModId15.GRANOLA_BAR)
end

function MetalMod:onPlayerInit(player)
	UpdateMetalMod(player)
end

MetalMod:AddCallback(ModCallbacks.MC_POST_PLAYER_INIT, MetalMod.onPlayerInit)

function MetalMod:onUpdate(player)
	UpdateMetalMod(player)
end

MetalMod:AddCallback(ModCallbacks.MC_POST_PEFFECT_UPDATE, MetalMod.onUpdate)

function MetalMod:onCache(player, cacheFlag)
	if cacheFlag == CacheFlag.CACHE_DAMAGE then
		if player:HasCollectible(MetalModId15.GRANOLA_BAR) and not HasMetalMod15.MetalMod then
			player.Damage = player.Damage + 0
		end
	end
	if cacheFlag == CacheFlag.CACHE_FIREDELAY then
		if player:HasCollectible(MetalModId15.GRANOLA_BAR) and not HasMetalMod15.MetalMod then
			player.MaxFireDelay = player.MaxFireDelay - 0
		end
	end
	if cacheFlag == CacheFlag.CACHE_LUCK then
		if player:HasCollectible(MetalModId15.GRANOLA_BAR) and not HasMetalMod15.MetalMod then
			player.Luck = player.Luck + 0
		end
	end
	if cacheFlag == CacheFlag.CACHE_SHOTSPEED then
		if player:HasCollectible(MetalModId15.GRANOLA_BAR) and not HasMetalMod15.MetalMod then
			player.ShotSpeed = player.ShotSpeed + 0
		end
	end
	if cacheFlag == CacheFlag.CACHE_SPEED then
		if player:HasCollectible(MetalModId15.GRANOLA_BAR) and not HasMetalMod15.MetalMod then
			player.MoveSpeed = player.MoveSpeed + 0
		end
	end
	if cacheFlag == CacheFlag.CACHE_RANGE then
		if player:HasCollectible(MetalModId15.GRANOLA_BAR) and not HasMetalMod15.MetalMod then
			player.TearRange = player.TearRange + 0
		end
	end
end

MetalMod:AddCallback(ModCallbacks.MC_EVALUATE_CACHE, MetalMod.onCache)

MetalMod.COLLECTIBLE_GRANOLA_BAR = Isaac.GetItemIdByName("Granola Bar")

function MetalMod:onUpdate()
	-- begin
	if Game():GetFrameCount() == 1 then
		MetalMod.HasMetalMod15 = false
	end
	
	-- functionality
	for playerNum = 1, Game():GetNumPlayers() do
		local player = Game():GetPlayer(playerNum)
		if player:HasCollectible(MetalMod.COLLECTIBLE_GRANOLA_BAR) then
			if not MetalMod.HasMetalMod15 then
				player:AddMaxHearts(2)
				player:AddHearts(4)
				MetalMod.HasMetalMod15 = true
				
			end
		end
	end
end

MetalMod:AddCallback(ModCallbacks.MC_POST_UPDATE,MetalMod.onUpdate)

-- Doctor Banana
local game = Game()

local MetalModId16 = {
	CORN = Isaac.GetItemIdByName("Corn")
}

local HasMetalMod16 = {
	MetalMod = false
}

local function UpdateMetalMod(player)
	MetalMod.HasMetalMod16 = player:HasCollectible(MetalModId16.CORN)
end

function MetalMod:onPlayerInit(player)
	UpdateMetalMod(player)
end

MetalMod:AddCallback(ModCallbacks.MC_POST_PLAYER_INIT, MetalMod.onPlayerInit)

function MetalMod:onUpdate(player)
	UpdateMetalMod(player)
end

MetalMod:AddCallback(ModCallbacks.MC_POST_PEFFECT_UPDATE, MetalMod.onUpdate)

function MetalMod:onCache(player, cacheFlag)
	if cacheFlag == CacheFlag.CACHE_DAMAGE then
		if player:HasCollectible(MetalModId16.CORN) and not HasMetalMod16.MetalMod then
			player.Damage = player.Damage + 1.25
		end
	end
	if cacheFlag == CacheFlag.CACHE_FIREDELAY then
		if player:HasCollectible(MetalModId16.CORN) and not HasMetalMod16.MetalMod then
			player.MaxFireDelay = player.MaxFireDelay - 0.5
		end
	end
	if cacheFlag == CacheFlag.CACHE_LUCK then
		if player:HasCollectible(MetalModId16.CORN) and not HasMetalMod16.MetalMod then
			player.Luck = player.Luck + 0
		end
	end
	if cacheFlag == CacheFlag.CACHE_SHOTSPEED then
		if player:HasCollectible(MetalModId16.CORN) and not HasMetalMod16.MetalMod then
			player.ShotSpeed = player.ShotSpeed + 0
		end
	end
	if cacheFlag == CacheFlag.CACHE_SPEED then
		if player:HasCollectible(MetalModId16.CORN) and not HasMetalMod16.MetalMod then
			player.MoveSpeed = player.MoveSpeed + 0.15
		end
	end
	if cacheFlag == CacheFlag.CACHE_RANGE then
		if player:HasCollectible(MetalModId16.CORN) and not HasMetalMod16.MetalMod then
			player.TearRange = player.TearRange + 0
		end
	end
end

MetalMod:AddCallback(ModCallbacks.MC_EVALUATE_CACHE, MetalMod.onCache)

MetalMod.COLLECTIBLE_CORN = Isaac.GetItemIdByName("Corn")

function MetalMod:onUpdate()
	-- begin
	if Game():GetFrameCount() == 1 then
		MetalMod.HasMetalMod16 = false
	end
	
	-- functionality
	for playerNum = 1, Game():GetNumPlayers() do
		local player = Game():GetPlayer(playerNum)
		if player:HasCollectible(MetalMod.COLLECTIBLE_CORN) then
			if not MetalMod.HasMetalMod16 then
				player:AddSoulHearts(2)
				MetalMod.HasMetalMod16 = true
				
			end
		end
	end
end

MetalMod:AddCallback(ModCallbacks.MC_POST_UPDATE,MetalMod.onUpdate)

-- Doctor Banana
local game = Game()

local MetalModId17 = {
	BIG_NUT = Isaac.GetItemIdByName("BIG NUT")
}

local HasMetalMod17 = {
	MetalMod = false
}

local function UpdateMetalMod(player)
	MetalMod.HasMetalMod17 = player:HasCollectible(MetalModId17.BIG_NUT)
end

function MetalMod:onPlayerInit(player)
	UpdateMetalMod(player)
end

MetalMod:AddCallback(ModCallbacks.MC_POST_PLAYER_INIT, MetalMod.onPlayerInit)

function MetalMod:onUpdate(player)
	UpdateMetalMod(player)
end

MetalMod:AddCallback(ModCallbacks.MC_POST_PEFFECT_UPDATE, MetalMod.onUpdate)

function MetalMod:onCache(player, cacheFlag)
	if cacheFlag == CacheFlag.CACHE_DAMAGE then
		if player:HasCollectible(MetalModId17.BIG_NUT) and not HasMetalMod17.MetalMod then
			player.Damage = player.Damage * 1.50
		end
	end
	if cacheFlag == CacheFlag.CACHE_FIREDELAY then
		if player:HasCollectible(MetalModId17.BIG_NUT) and not HasMetalMod17.MetalMod then
			player.MaxFireDelay = player.MaxFireDelay - 1
		end
	end
	if cacheFlag == CacheFlag.CACHE_LUCK then
		if player:HasCollectible(MetalModId17.BIG_NUT) and not HasMetalMod17.MetalMod then
			player.Luck = player.Luck + 1
		end
	end
	if cacheFlag == CacheFlag.CACHE_SHOTSPEED then
		if player:HasCollectible(MetalModId17.BIG_NUT) and not HasMetalMod17.MetalMod then
			player.ShotSpeed = player.ShotSpeed + 0
		end
	end
	if cacheFlag == CacheFlag.CACHE_SPEED then
		if player:HasCollectible(MetalModId17.BIG_NUT) and not HasMetalMod17.MetalMod then
			player.MoveSpeed = player.MoveSpeed + 0.25
		end
	end
	if cacheFlag == CacheFlag.CACHE_RANGE then
		if player:HasCollectible(MetalModId17.BIG_NUT) and not HasMetalMod17.MetalMod then
			player.TearRange = player.TearRange + 0
		end
	end
end

MetalMod:AddCallback(ModCallbacks.MC_EVALUATE_CACHE, MetalMod.onCache)

MetalMod.COLLECTIBLE_BIG_NUT = Isaac.GetItemIdByName("BIG NUT")

function MetalMod:onUpdate()
	-- begin
	if Game():GetFrameCount() == 1 then
		MetalMod.HasMetalMod17 = false
	end
	
	-- functionality
	for playerNum = 1, Game():GetNumPlayers() do
		local player = Game():GetPlayer(playerNum)
		if player:HasCollectible(MetalMod.COLLECTIBLE_BIG_NUT) then
			if not MetalMod.HasMetalMod17 then
				player:AddMaxHearts(4)
				player:AddHearts(6)
				MetalMod.HasMetalMod17 = true
				
			end
		end
	end
end

MetalMod:AddCallback(ModCallbacks.MC_POST_UPDATE,MetalMod.onUpdate)

-- Doctor Banana
local game = Game()

local MetalModId18 = {
	MA_BOI_ISAAC = Isaac.GetItemIdByName("Ma Boi Isaac")
}

local HasMetalMod18 = {
	MetalMod = false
}

local function UpdateMetalMod(player)
	MetalMod.HasMetalMod18 = player:HasCollectible(MetalModId18.MA_BOI_ISAAC)
end

function MetalMod:onPlayerInit(player)
	UpdateMetalMod(player)
end

MetalMod:AddCallback(ModCallbacks.MC_POST_PLAYER_INIT, MetalMod.onPlayerInit)

function MetalMod:onUpdate(player)
	UpdateMetalMod(player)
end

MetalMod:AddCallback(ModCallbacks.MC_POST_PEFFECT_UPDATE, MetalMod.onUpdate)

function MetalMod:onCache(player, cacheFlag)
	if cacheFlag == CacheFlag.CACHE_DAMAGE then
		if player:HasCollectible(MetalModId18.MA_BOI_ISAAC) and not HasMetalMod18.MetalMod then
			player.Damage = player.Damage + 1.75
		end
	end
	if cacheFlag == CacheFlag.CACHE_FIREDELAY then
		if player:HasCollectible(MetalModId18.MA_BOI_ISAAC) and not HasMetalMod18.MetalMod then
			player.MaxFireDelay = player.MaxFireDelay - 0
		end
	end
	if cacheFlag == CacheFlag.CACHE_LUCK then
		if player:HasCollectible(MetalModId18.MA_BOI_ISAAC) and not HasMetalMod18.MetalMod then
			player.Luck = player.Luck + 0
		end
	end
	if cacheFlag == CacheFlag.CACHE_SHOTSPEED then
		if player:HasCollectible(MetalModId18.MA_BOI_ISAAC) and not HasMetalMod18.MetalMod then
			player.ShotSpeed = player.ShotSpeed + 0
		end
	end
	if cacheFlag == CacheFlag.CACHE_SPEED then
		if player:HasCollectible(MetalModId18.MA_BOI_ISAAC) and not HasMetalMod18.MetalMod then
			player.MoveSpeed = player.MoveSpeed + 0
		end
	end
	if cacheFlag == CacheFlag.CACHE_RANGE then
		if player:HasCollectible(MetalModId18.MA_BOI_ISAAC) and not HasMetalMod18.MetalMod then
			player.TearRange = player.TearRange + 0
		end
	end
end

MetalMod:AddCallback(ModCallbacks.MC_EVALUATE_CACHE, MetalMod.onCache)

MetalMod.COLLECTIBLE_MA_BOI_ISAAC = Isaac.GetItemIdByName("Ma Boi Isaac")

function MetalMod:onUpdate()
	-- begin
	if Game():GetFrameCount() == 1 then
		MetalMod.HasMetalMod18 = false
	end
	
	-- functionality
	for playerNum = 1, Game():GetNumPlayers() do
		local player = Game():GetPlayer(playerNum)
		if player:HasCollectible(MetalMod.COLLECTIBLE_MA_BOI_ISAAC) then
			if not MetalMod.HasMetalMod18 then
				MetalMod.HasMetalMod18 = true
				
			end
		end
	end
end

MetalMod:AddCallback(ModCallbacks.MC_POST_UPDATE,MetalMod.onUpdate)

-- Doctor Banana
local game = Game()

local MetalModId19 = {
	REALLY_COOL_SWORD = Isaac.GetItemIdByName("Really Cool Sword")
}

local HasMetalMod19 = {
	MetalMod = false
}

local function UpdateMetalMod(player)
	MetalMod.HasMetalMod19 = player:HasCollectible(MetalModId19.REALLY_COOL_SWORD)
end

function MetalMod:onPlayerInit(player)
	UpdateMetalMod(player)
end

MetalMod:AddCallback(ModCallbacks.MC_POST_PLAYER_INIT, MetalMod.onPlayerInit)

function MetalMod:onUpdate(player)
	UpdateMetalMod(player)
end

MetalMod:AddCallback(ModCallbacks.MC_POST_PEFFECT_UPDATE, MetalMod.onUpdate)

function MetalMod:onCache(player, cacheFlag)
	if cacheFlag == CacheFlag.CACHE_DAMAGE then
		if player:HasCollectible(MetalModId19.REALLY_COOL_SWORD) and not HasMetalMod19.MetalMod then
			player.Damage = player.Damage * 1.40
		end
	end
	if cacheFlag == CacheFlag.CACHE_FIREDELAY then
		if player:HasCollectible(MetalModId19.REALLY_COOL_SWORD) and not HasMetalMod19.MetalMod then
			player.MaxFireDelay = player.MaxFireDelay - 0
		end
	end
	if cacheFlag == CacheFlag.CACHE_LUCK then
		if player:HasCollectible(MetalModId19.REALLY_COOL_SWORD) and not HasMetalMod19.MetalMod then
			player.Luck = player.Luck + 0
		end
	end
	if cacheFlag == CacheFlag.CACHE_SHOTSPEED then
		if player:HasCollectible(MetalModId19.REALLY_COOL_SWORD) and not HasMetalMod19.MetalMod then
			player.ShotSpeed = player.ShotSpeed + 0
		end
	end
	if cacheFlag == CacheFlag.CACHE_SPEED then
		if player:HasCollectible(MetalModId19.REALLY_COOL_SWORD) and not HasMetalMod19.MetalMod then
			player.MoveSpeed = player.MoveSpeed + 0
		end
	end
	if cacheFlag == CacheFlag.CACHE_RANGE then
		if player:HasCollectible(MetalModId19.REALLY_COOL_SWORD) and not HasMetalMod19.MetalMod then
			player.TearRange = player.TearRange + 0
		end
	end
end

MetalMod:AddCallback(ModCallbacks.MC_EVALUATE_CACHE, MetalMod.onCache)

MetalMod.COLLECTIBLE_REALLY_COOL_SWORD = Isaac.GetItemIdByName("Really Cool Sword")

function MetalMod:onUpdate()
	-- begin
	if Game():GetFrameCount() == 1 then
		MetalMod.HasMetalMod19 = false
	end
	
	-- functionality
	for playerNum = 1, Game():GetNumPlayers() do
		local player = Game():GetPlayer(playerNum)
		if player:HasCollectible(MetalMod.COLLECTIBLE_REALLY_COOL_SWORD) then
			if not MetalMod.HasMetalMod19 then
				MetalMod.HasMetalMod19 = true
				
			end
		end
	end
end

MetalMod:AddCallback(ModCallbacks.MC_POST_UPDATE,MetalMod.onUpdate)

-- Doctor Banana
local game = Game()

local MetalModId20 = {
	GR0G = Isaac.GetItemIdByName("gr0g")
}

local HasMetalMod20 = {
	MetalMod = false
}

local function UpdateMetalMod(player)
	MetalMod.HasMetalMod20 = player:HasCollectible(MetalModId20.GR0G)
end

function MetalMod:onPlayerInit(player)
	UpdateMetalMod(player)
end

MetalMod:AddCallback(ModCallbacks.MC_POST_PLAYER_INIT, MetalMod.onPlayerInit)

function MetalMod:onUpdate(player)
	UpdateMetalMod(player)
end

MetalMod:AddCallback(ModCallbacks.MC_POST_PEFFECT_UPDATE, MetalMod.onUpdate)

function MetalMod:onCache(player, cacheFlag)
	if cacheFlag == CacheFlag.CACHE_DAMAGE then
		if player:HasCollectible(MetalModId20.GR0G) and not HasMetalMod20.MetalMod then
			player.Damage = player.Damage + 0.75
		end
	end
	if cacheFlag == CacheFlag.CACHE_FIREDELAY then
		if player:HasCollectible(MetalModId20.GR0G) and not HasMetalMod20.MetalMod then
			player.MaxFireDelay = player.MaxFireDelay - 0
		end
	end
	if cacheFlag == CacheFlag.CACHE_LUCK then
		if player:HasCollectible(MetalModId20.GR0G) and not HasMetalMod20.MetalMod then
			player.Luck = player.Luck + 0
		end
	end
	if cacheFlag == CacheFlag.CACHE_SHOTSPEED then
		if player:HasCollectible(MetalModId20.GR0G) and not HasMetalMod20.MetalMod then
			player.ShotSpeed = player.ShotSpeed + 0
		end
	end
	if cacheFlag == CacheFlag.CACHE_SPEED then
		if player:HasCollectible(MetalModId20.GR0G) and not HasMetalMod20.MetalMod then
			player.MoveSpeed = player.MoveSpeed + 0
		end
	end
	if cacheFlag == CacheFlag.CACHE_RANGE then
		if player:HasCollectible(MetalModId20.GR0G) and not HasMetalMod20.MetalMod then
			player.TearRange = player.TearRange + 0
		end
	end
end

MetalMod:AddCallback(ModCallbacks.MC_EVALUATE_CACHE, MetalMod.onCache)

MetalMod.COLLECTIBLE_GR0G = Isaac.GetItemIdByName("gr0g")

function MetalMod:onUpdate()
	-- begin
	if Game():GetFrameCount() == 1 then
		MetalMod.HasMetalMod20 = false
	end
	
	-- functionality
	for playerNum = 1, Game():GetNumPlayers() do
		local player = Game():GetPlayer(playerNum)
		if player:HasCollectible(MetalMod.COLLECTIBLE_GR0G) then
			if not MetalMod.HasMetalMod20 then
				player:AddCoins(5)
				MetalMod.HasMetalMod20 = true
				
			end
		end
	end
end

MetalMod:AddCallback(ModCallbacks.MC_POST_UPDATE,MetalMod.onUpdate) 

-- Doctor Banana
local game = Game()

local MetalModId21 = {
	TEK_EFFECT = Isaac.GetItemIdByName("Tek Effect")
}

local HasMetalMod21 = {
	MetalMod = false
}

local function UpdateMetalMod(player)
	MetalMod.HasMetalMod21 = player:HasCollectible(MetalModId21.TEK_EFFECT)
end

function MetalMod:onPlayerInit(player)
	UpdateMetalMod(player)
end

MetalMod:AddCallback(ModCallbacks.MC_POST_PLAYER_INIT, MetalMod.onPlayerInit)

function MetalMod:onUpdate(player)
	UpdateMetalMod(player)
end

MetalMod:AddCallback(ModCallbacks.MC_POST_PEFFECT_UPDATE, MetalMod.onUpdate)

function MetalMod:onCache(player, cacheFlag)
	if cacheFlag == CacheFlag.CACHE_DAMAGE then
		if player:HasCollectible(MetalModId21.TEK_EFFECT) and not HasMetalMod21.MetalMod then
			player.Damage = player.Damage + 4
		end
	end
	if cacheFlag == CacheFlag.CACHE_FIREDELAY then
		if player:HasCollectible(MetalModId21.TEK_EFFECT) and not HasMetalMod21.MetalMod then
			player.MaxFireDelay = player.MaxFireDelay - 2
		end
	end
	if cacheFlag == CacheFlag.CACHE_LUCK then
		if player:HasCollectible(MetalModId21.TEK_EFFECT) and not HasMetalMod21.MetalMod then
			player.Luck = player.Luck + 0
		end
	end
	if cacheFlag == CacheFlag.CACHE_SHOTSPEED then
		if player:HasCollectible(MetalModId21.TEK_EFFECT) and not HasMetalMod21.MetalMod then
			player.ShotSpeed = player.ShotSpeed + 0
		end
	end
	if cacheFlag == CacheFlag.CACHE_SPEED then
		if player:HasCollectible(MetalModId21.TEK_EFFECT) and not HasMetalMod21.MetalMod then
			player.MoveSpeed = player.MoveSpeed - 0.1
		end
	end
	if cacheFlag == CacheFlag.CACHE_RANGE then
		if player:HasCollectible(MetalModId21.TEK_EFFECT) and not HasMetalMod21.MetalMod then
			player.TearRange = player.TearRange + 0
		end
	end
end

MetalMod:AddCallback(ModCallbacks.MC_EVALUATE_CACHE, MetalMod.onCache)

MetalMod.COLLECTIBLE_TEK_EFFECT = Isaac.GetItemIdByName("Tek Effect")

function MetalMod:onUpdate()
	-- begin
	if Game():GetFrameCount() == 1 then
		MetalMod.HasMetalMod21 = false
	end
	
	-- functionality
	for playerNum = 1, Game():GetNumPlayers() do
		local player = Game():GetPlayer(playerNum)
		if player:HasCollectible(MetalMod.COLLECTIBLE_TEK_EFFECT) then
			if not MetalMod.HasMetalMod21 then
				MetalMod.HasMetalMod21 = true
				
			end
		end
	end
end

MetalMod:AddCallback(ModCallbacks.MC_POST_UPDATE,MetalMod.onUpdate) 

function MetalMod:onNewRoom()
	for playerNum = 1, Game():GetNumPlayers() do
		local player = Game():GetPlayer(playerNum)
		if player:HasCollectible(MetalMod.COLLECTIBLE_TEK_EFFECT) then
			player:RemoveCollectible(MetalMod.COLLECTIBLE_TEK_EFFECT)
		end
	end
end

MetalMod:AddCallback(ModCallbacks.MC_POST_NEW_ROOM,MetalMod.onNewRoom)

-- Doctor Banana
local game = Game()

local MetalModId22 = {
	SKILL_ISSUE = Isaac.GetItemIdByName("Skill Issue")
}

local HasMetalMod22 = {
	MetalMod = false
}

local function UpdateMetalMod(player)
	MetalMod.HasMetalMod22 = player:HasCollectible(MetalModId22.SKILL_ISSUE)
end

function MetalMod:onPlayerInit(player)
	UpdateMetalMod(player)
end

MetalMod:AddCallback(ModCallbacks.MC_POST_PLAYER_INIT, MetalMod.onPlayerInit)

function MetalMod:onUpdate(player)
	UpdateMetalMod(player)
end

MetalMod:AddCallback(ModCallbacks.MC_POST_PEFFECT_UPDATE, MetalMod.onUpdate)

function MetalMod:onCache(player, cacheFlag)
	if cacheFlag == CacheFlag.CACHE_DAMAGE then
		if player:HasCollectible(MetalModId22.SKILL_ISSUE) and not HasMetalMod22.MetalMod then
			player.Damage = player.Damage + 3.5
		end
	end
	if cacheFlag == CacheFlag.CACHE_FIREDELAY then
		if player:HasCollectible(MetalModId22.SKILL_ISSUE) and not HasMetalMod22.MetalMod then
			player.MaxFireDelay = player.MaxFireDelay - 0.7
		end
	end
	if cacheFlag == CacheFlag.CACHE_LUCK then
		if player:HasCollectible(MetalModId22.SKILL_ISSUE) and not HasMetalMod22.MetalMod then
			player.Luck = player.Luck + 0
		end
	end
	if cacheFlag == CacheFlag.CACHE_SHOTSPEED then
		if player:HasCollectible(MetalModId22.SKILL_ISSUE) and not HasMetalMod22.MetalMod then
			player.ShotSpeed = player.ShotSpeed + 0
		end
	end
	if cacheFlag == CacheFlag.CACHE_SPEED then
		if player:HasCollectible(MetalModId22.SKILL_ISSUE) and not HasMetalMod22.MetalMod then
			player.MoveSpeed = player.MoveSpeed - 0
		end
	end
	if cacheFlag == CacheFlag.CACHE_RANGE then
		if player:HasCollectible(MetalModId22.SKILL_ISSUE) and not HasMetalMod22.MetalMod then
			player.TearRange = player.TearRange + 0
		end
	end
end

MetalMod:AddCallback(ModCallbacks.MC_EVALUATE_CACHE, MetalMod.onCache)

MetalMod.COLLECTIBLE_SKILL_ISSUE = Isaac.GetItemIdByName("Skill Issue")

function MetalMod:onUpdate()
	-- begin
	if Game():GetFrameCount() == 1 then
		MetalMod.HasMetalMod22 = false
	end
	
	-- functionality
	for playerNum = 1, Game():GetNumPlayers() do
		local player = Game():GetPlayer(playerNum)
		if player:HasCollectible(MetalMod.COLLECTIBLE_SKILL_ISSUE) then
			if not MetalMod.HasMetalMod22 then
				MetalMod.HasMetalMod22 = true
				
			end
		end
	end
end

MetalMod:AddCallback(ModCallbacks.MC_POST_UPDATE,MetalMod.onUpdate) 

function MetalMod:onNewRoom(ToNPC, npc)
	for playerNum = 1, Game():GetNumPlayers() do
		local player = Game():GetPlayer(playerNum)
		if player:HasCollectible(MetalMod.COLLECTIBLE_SKILL_ISSUE) then
			local entitiesSkill = Isaac.GetRoomEntities()
			for i = 1, #entitiesSkill do
				local entSkill = entitiesSkill[i]
				if entSkill:IsEnemy() == true then
					entSkill:ToNPC():MakeChampion(entSkill.InitSeed, -1)
				end
			end
		end
	end
end

MetalMod:AddCallback(ModCallbacks.MC_POST_NEW_ROOM,MetalMod.onNewRoom)







-- Common Mystery
local game = Game()

local MetalModId7 = {
	COMMON_MYSTERY = Isaac.GetItemIdByName("Common Mystery")
}

local HasMetalMod7 = {
	MetalMod = false
}

local function UpdateMetalMod(player)
	MetalMod.HasMetalMod7 = player:HasCollectible(MetalModId7.COMMON_MYSTERY)
end

function MetalMod:onPlayerInit(player)
	UpdateMetalMod(player)
end

MetalMod:AddCallback(ModCallbacks.MC_POST_PLAYER_INIT, MetalMod.onPlayerInit)

function MetalMod:onUpdate(player)
	UpdateMetalMod(player)
end

MetalMod:AddCallback(ModCallbacks.MC_POST_PEFFECT_UPDATE, MetalMod.onUpdate)

MetalMod.COLLECTIBLE_COMMON_MYSTERY = Isaac.GetItemIdByName("Common Mystery")

function MetalMod:onUpdate()
	-- begin
	if Game():GetFrameCount() == 1 then
		MetalMod.HasMetalMod7 = false
	end
	
	-- functionality
	for playerNum = 1, Game():GetNumPlayers() do
		local player = Game():GetPlayer(playerNum)
		if player:HasCollectible(MetalMod.COLLECTIBLE_COMMON_MYSTERY) then
			if not MetalMod.HasMetalMod7 then
				local common_mystery_reward = math.random(1,10)
				if common_mystery_reward == 1 then
					--haha no item RATIOOOO
				elseif common_mystery_reward == 2 then
					Isaac.Spawn(5, 10, 1, Isaac.GetFreeNearPosition(Isaac.GetPlayer(0).Position,30),Vector(1,-1), player)
				elseif common_mystery_reward == 3 then
					Isaac.Spawn(5, 30, 1, Isaac.GetFreeNearPosition(Isaac.GetPlayer(0).Position,30),Vector(1,-1), player)
				elseif common_mystery_reward == 4 then
					Isaac.Spawn(5, 30, 1, Isaac.GetFreeNearPosition(Isaac.GetPlayer(0).Position,30),Vector(-1,-1), player)
				elseif common_mystery_reward == 5 then
					Isaac.Spawn(5, 40, 1, Isaac.GetFreeNearPosition(Isaac.GetPlayer(0).Position,30),Vector(-1,1), player)
				elseif common_mystery_reward == 6 then
					Isaac.Spawn(5, 40, 1, Isaac.GetFreeNearPosition(Isaac.GetPlayer(0).Position,30),Vector(-1,-1), player)
				elseif common_mystery_reward == 7 then
					Isaac.Spawn(5, 10, 3, Isaac.GetFreeNearPosition(Isaac.GetPlayer(0).Position,30),Vector(1,1), player)
				elseif common_mystery_reward == 8 then
					Isaac.Spawn(5, 40, 2, Isaac.GetFreeNearPosition(Isaac.GetPlayer(0).Position,30),Vector(-1,-1), player)
				elseif common_mystery_reward == 9 then
					Isaac.Spawn(5, 30, 2, Isaac.GetFreeNearPosition(Isaac.GetPlayer(0).Position,30),Vector(-1,1), player)
				elseif common_mystery_reward == 10 then
					Isaac.Spawn(5, 100, -1, Isaac.GetFreeNearPosition(Isaac.GetPlayer(0).Position,30),Vector(1,-1), player)
				end
				player:RemoveCollectible(MetalMod.COLLECTIBLE_COMMON_MYSTERY)
			end
		end
	end
end

MetalMod:AddCallback(ModCallbacks.MC_POST_UPDATE,MetalMod.onUpdate)

-- Rare Mystery
local game = Game()

local MetalModId8 = {
	RARE_MYSTERY = Isaac.GetItemIdByName("Rare Mystery")
}

local HasMetalMod8 = {
	MetalMod = false
}

local function UpdateMetalMod(player)
	MetalMod.HasMetalMod8 = player:HasCollectible(MetalModId8.RARE_MYSTERY)
end

function MetalMod:onPlayerInit(player)
	UpdateMetalMod(player)
end

MetalMod:AddCallback(ModCallbacks.MC_POST_PLAYER_INIT, MetalMod.onPlayerInit)

function MetalMod:onUpdate(player)
	UpdateMetalMod(player)
end

MetalMod:AddCallback(ModCallbacks.MC_POST_PEFFECT_UPDATE, MetalMod.onUpdate)

MetalMod.COLLECTIBLE_RARE_MYSTERY = Isaac.GetItemIdByName("Rare Mystery")

function MetalMod:onUpdate()
	-- begin
	if Game():GetFrameCount() == 1 then
		MetalMod.HasMetalMod8 = false
	end
	
	-- functionality
	for playerNum = 1, Game():GetNumPlayers() do
		local player = Game():GetPlayer(playerNum)
		if player:HasCollectible(MetalMod.COLLECTIBLE_RARE_MYSTERY) then
			if not MetalMod.HasMetalMod8 then
				local RARE_MYSTERY_reward = math.random(1,10)
				if RARE_MYSTERY_reward == 1 then
					Isaac.Spawn(5, 100, 0, Isaac.GetFreeNearPosition(Isaac.GetPlayer(0).Position,30),Vector(0,0), player)
				elseif RARE_MYSTERY_reward == 2 then
					Isaac.Spawn(5, 100, -1, Isaac.GetFreeNearPosition(Isaac.GetPlayer(0).Position,30),Vector(1,-1), player)
				elseif RARE_MYSTERY_reward == 3 then
					Isaac.Spawn(5, 40, 1, Isaac.GetFreeNearPosition(Isaac.GetPlayer(0).Position,30),Vector(-1,-1), player)
				elseif RARE_MYSTERY_reward == 4 then
					Isaac.Spawn(5, 30, 1, Isaac.GetFreeNearPosition(Isaac.GetPlayer(0).Position,30),Vector(1,-1), player)
				elseif RARE_MYSTERY_reward == 5 then
					Isaac.Spawn(5, 40, 2, Isaac.GetFreeNearPosition(Isaac.GetPlayer(0).Position,30),Vector(-1,-1), player)
				elseif RARE_MYSTERY_reward == 6 then
					Isaac.Spawn(5, 30, 3, Isaac.GetFreeNearPosition(Isaac.GetPlayer(0).Position,30),Vector(-1,-1), player)
				elseif RARE_MYSTERY_reward == 7 then
					Isaac.Spawn(5, 10, 3, Isaac.GetFreeNearPosition(Isaac.GetPlayer(0).Position,30),Vector(-1,-1), player)
				elseif RARE_MYSTERY_reward == 8 then
					Isaac.Spawn(5, 10, 3, Isaac.GetFreeNearPosition(Isaac.GetPlayer(0).Position,30),Vector(-1,-1), player)
				elseif RARE_MYSTERY_reward == 9 then
					Isaac.Spawn(5, 10, 3, Isaac.GetFreeNearPosition(Isaac.GetPlayer(0).Position,30),Vector(-1,-1), player)
				elseif RARE_MYSTERY_reward == 10 then
					Isaac.Spawn(5, 20, 2, Isaac.GetFreeNearPosition(Isaac.GetPlayer(0).Position,30),Vector(-1,-1), player)
				end
				player:RemoveCollectible(MetalMod.COLLECTIBLE_RARE_MYSTERY)
			end
		end
	end
end

MetalMod:AddCallback(ModCallbacks.MC_POST_UPDATE,MetalMod.onUpdate)

-- Legendary Mystery
local game = Game()

local MetalModId9 = {
	LEGENDARY_MYSTERY = Isaac.GetItemIdByName("Legendary Mystery")
}

local HasMetalMod9 = {
	MetalMod = false
}

local function UpdateMetalMod(player)
	MetalMod.HasMetalMod9 = player:HasCollectible(MetalModId9.LEGENDARY_MYSTERY)
end

function MetalMod:onPlayerInit(player)
	UpdateMetalMod(player)
end

MetalMod:AddCallback(ModCallbacks.MC_POST_PLAYER_INIT, MetalMod.onPlayerInit)

function MetalMod:onUpdate(player)
	UpdateMetalMod(player)
end

MetalMod:AddCallback(ModCallbacks.MC_POST_PEFFECT_UPDATE, MetalMod.onUpdate)

MetalMod.COLLECTIBLE_LEGENDARY_MYSTERY = Isaac.GetItemIdByName("Legendary Mystery")

function MetalMod:onUpdate()
	-- begin
	if Game():GetFrameCount() == 1 then
		MetalMod.HasMetalMod9 = false
	end
	
	-- functionality
	for playerNum = 1, Game():GetNumPlayers() do
		local player = Game():GetPlayer(playerNum)
		if player:HasCollectible(MetalMod.COLLECTIBLE_LEGENDARY_MYSTERY) then
			if not MetalMod.HasMetalMod9 then
				local LEGENDARY_MYSTERY_reward = math.random(1,6)
				if LEGENDARY_MYSTERY_reward == 1 then
					Isaac.Spawn(5, 100, -1, Isaac.GetFreeNearPosition(Isaac.GetPlayer(0).Position,30),Vector(0,0), player)
				elseif LEGENDARY_MYSTERY_reward == 2 then
					Isaac.Spawn(5, 30, 2, Isaac.GetFreeNearPosition(Isaac.GetPlayer(0).Position,30),Vector(1,-1), player)
				elseif LEGENDARY_MYSTERY_reward == 3 then
					Isaac.Spawn(5, 40, 4, Isaac.GetFreeNearPosition(Isaac.GetPlayer(0).Position,30),Vector(-1,-1), player)
				elseif LEGENDARY_MYSTERY_reward == 4 then
					Isaac.Spawn(5, 100, -1, Isaac.GetFreeNearPosition(Isaac.GetPlayer(0).Position,30),Vector(0,0), player)
				elseif LEGENDARY_MYSTERY_reward == 5 then
					Isaac.Spawn(5, 100, -1, Isaac.GetFreeNearPosition(Isaac.GetPlayer(0).Position,30),Vector(0,0), player)
				elseif LEGENDARY_MYSTERY_reward == 6 then
					Isaac.Spawn(5, 20, 3, Isaac.GetFreeNearPosition(Isaac.GetPlayer(0).Position,30),Vector(0,0), player)
				end
				player:RemoveCollectible(MetalMod.COLLECTIBLE_LEGENDARY_MYSTERY)
			end
		end
	end
end

MetalMod:AddCallback(ModCallbacks.MC_POST_UPDATE,MetalMod.onUpdate)


local common_mystery = Isaac.GetItemIdByName("Common Mystery")
local rare_mystery = Isaac.GetItemIdByName("Rare Mystery")
local legendary_mystery = Isaac.GetItemIdByName("Legendary Mystery")


function MetalMod:onNewRoom()
	for playerNum = 1, Game():GetNumPlayers() do
		local player = Game():GetPlayer(playerNum)
		if player:GetName() == "Metal" then
			local room = Game():GetRoom()
			if room:GetType() == RoomType.ROOM_TREASURE then
				if room:IsFirstVisit() then
					if room:GetRoomShape() == 1 then
						if math.random(1,1) == 10000000000000000000000000 then
							for i, entity in pairs(Isaac.GetRoomEntities()) do
								if entity:IsEnemy() then
									entity:Remove()
								end
							end
							local ent2 = Isaac.FindByType(5, 100, -1)
							for i=1, #ent2 do
								local pos2 = ent2[i].Position
								ent2[i]:Remove()
							end
							local ent3 = Isaac.FindByType(6, 10, 0)
							for i=1, #ent3 do
								local pos3 = ent3[i].Position
								ent3[i]:Remove()
							end
							Isaac.Spawn(17, 3, 0, Isaac.GetFreeNearPosition(Vector(320, 200),30), Vector(0,0), player)
							local spawnItem = Isaac.Spawn(5,100,common_mystery, Vector(280, 320), Vector(0,0), nil):ToPickup()
							spawnItem.Price = 3
							spawnItem.AutoUpdatePrice = false
							local data = spawnItem:GetData()
							data.Price = 3
							data.AutoUpdatePrice = false
							local spawnItem = Isaac.Spawn(5,100,rare_mystery, Vector(320, 320), Vector(0,0), nil):ToPickup()
							spawnItem.Price = 7
							spawnItem.AutoUpdatePrice = false
							local data = spawnItem:GetData()
							data.Price = 7
							data.AutoUpdatePrice = false
							local spawnItem = Isaac.Spawn(5,100,legendary_mystery, Vector(360, 320), Vector(0,0), nil):ToPickup()
							spawnItem.Price = 15
							spawnItem.AutoUpdatePrice = false
							local data = spawnItem:GetData()
							data.Price = 15
							data.AutoUpdatePrice = false
						end
					end
				end
			end
		end
		if player:GetName() == "Tainted Metal" then
			local room = Game():GetRoom()
			if room:GetType() == RoomType.ROOM_TREASURE then
				if room:IsFirstVisit() then
					if room:GetRoomShape() == 1 then
						if math.random(1,1) == 10000000000000000 then
							for i, entity in pairs(Isaac.GetRoomEntities()) do
								if entity:IsEnemy() then
									entity:Remove()
								end
							end
							local ent2 = Isaac.FindByType(5, 100, -1)
							for i=1, #ent2 do
								local pos2 = ent2[i].Position
								ent2[i]:Remove()
							end
							local ent3 = Isaac.FindByType(6, 10, 0)
							for i=1, #ent3 do
								local pos3 = ent3[i].Position
								ent3[i]:Remove()
							end
							Isaac.Spawn(17, 3, 0, Isaac.GetFreeNearPosition(Vector(320, 200),30), Vector(0,0), player)
							local spawnItem = Isaac.Spawn(5,100,common_mystery, Vector(280, 320), Vector(0,0), nil):ToPickup()
							spawnItem.Price = 3
							spawnItem.AutoUpdatePrice = false
							local data = spawnItem:GetData()
							data.Price = 3
							data.AutoUpdatePrice = false
							local spawnItem = Isaac.Spawn(5,100,common_mystery, Vector(280, 320), Vector(0,0), nil):ToPickup()
							spawnItem.Price = 3
							spawnItem.AutoUpdatePrice = false
							local data = spawnItem:GetData()
							data.Price = 3
							data.AutoUpdatePrice = false
							local spawnItem = Isaac.Spawn(5,100,common_mystery, Vector(280, 320), Vector(0,0), nil):ToPickup()
							spawnItem.Price = 3
							spawnItem.AutoUpdatePrice = false
							local data = spawnItem:GetData()
							data.Price = 3
							data.AutoUpdatePrice = false
							local spawnItem = Isaac.Spawn(5,100,common_mystery, Vector(280, 320), Vector(0,0), nil):ToPickup()
							spawnItem.Price = 3
							spawnItem.AutoUpdatePrice = false
							local data = spawnItem:GetData()
							data.Price = 3
							data.AutoUpdatePrice = false
							local spawnItem = Isaac.Spawn(5,100,common_mystery, Vector(280, 320), Vector(0,0), nil):ToPickup()
							spawnItem.Price = 3
							spawnItem.AutoUpdatePrice = false
							local data = spawnItem:GetData()
							data.Price = 3
							data.AutoUpdatePrice = false
							local spawnItem = Isaac.Spawn(5,100,common_mystery, Vector(280, 320), Vector(0,0), nil):ToPickup()
							spawnItem.Price = 3
							spawnItem.AutoUpdatePrice = false
							local data = spawnItem:GetData()
							data.Price = 3
							data.AutoUpdatePrice = false
							local spawnItem = Isaac.Spawn(5,100,common_mystery, Vector(280, 320), Vector(0,0), nil):ToPickup()
							spawnItem.Price = 3
							spawnItem.AutoUpdatePrice = false
							local data = spawnItem:GetData()
							data.Price = 3
							data.AutoUpdatePrice = false
							local spawnItem = Isaac.Spawn(5,100,common_mystery, Vector(280, 320), Vector(0,0), nil):ToPickup()
							spawnItem.Price = 3
							spawnItem.AutoUpdatePrice = false
							local data = spawnItem:GetData()
							data.Price = 3
							data.AutoUpdatePrice = false
							local spawnItem = Isaac.Spawn(5,100,common_mystery, Vector(280, 320), Vector(0,0), nil):ToPickup()
							spawnItem.Price = 3
							spawnItem.AutoUpdatePrice = false
							local data = spawnItem:GetData()
							data.Price = 3
							data.AutoUpdatePrice = false
							local spawnItem = Isaac.Spawn(5,100,common_mystery, Vector(280, 320), Vector(0,0), nil):ToPickup()
							spawnItem.Price = 3
							spawnItem.AutoUpdatePrice = false
							local data = spawnItem:GetData()
							data.Price = 3
							data.AutoUpdatePrice = false
							local spawnItem = Isaac.Spawn(5,100,rare_mystery, Vector(320, 320), Vector(0,0), nil):ToPickup()
							spawnItem.Price = 7
							spawnItem.AutoUpdatePrice = false
							local data = spawnItem:GetData()
							data.Price = 7
							data.AutoUpdatePrice = false
							local spawnItem = Isaac.Spawn(5,100,rare_mystery, Vector(320, 320), Vector(0,0), nil):ToPickup()
							spawnItem.Price = 7
							spawnItem.AutoUpdatePrice = false
							local data = spawnItem:GetData()
							data.Price = 7
							data.AutoUpdatePrice = false
							local spawnItem = Isaac.Spawn(5,100,rare_mystery, Vector(320, 320), Vector(0,0), nil):ToPickup()
							spawnItem.Price = 7
							spawnItem.AutoUpdatePrice = false
							local data = spawnItem:GetData()
							data.Price = 7
							data.AutoUpdatePrice = false
							local spawnItem = Isaac.Spawn(5,100,rare_mystery, Vector(320, 320), Vector(0,0), nil):ToPickup()
							spawnItem.Price = 7
							spawnItem.AutoUpdatePrice = false
							local data = spawnItem:GetData()
							data.Price = 7
							data.AutoUpdatePrice = false
							local spawnItem = Isaac.Spawn(5,100,rare_mystery, Vector(320, 320), Vector(0,0), nil):ToPickup()
							spawnItem.Price = 7
							spawnItem.AutoUpdatePrice = false
							local data = spawnItem:GetData()
							data.Price = 7
							data.AutoUpdatePrice = false
							local spawnItem = Isaac.Spawn(5,100,rare_mystery, Vector(320, 320), Vector(0,0), nil):ToPickup()
							spawnItem.Price = 7
							spawnItem.AutoUpdatePrice = false
							local data = spawnItem:GetData()
							data.Price = 7
							data.AutoUpdatePrice = false
							local spawnItem = Isaac.Spawn(5,100,rare_mystery, Vector(320, 320), Vector(0,0), nil):ToPickup()
							spawnItem.Price = 7
							spawnItem.AutoUpdatePrice = false
							local data = spawnItem:GetData()
							data.Price = 7
							data.AutoUpdatePrice = false
							local spawnItem = Isaac.Spawn(5,100,rare_mystery, Vector(320, 320), Vector(0,0), nil):ToPickup()
							spawnItem.Price = 7
							spawnItem.AutoUpdatePrice = false
							local data = spawnItem:GetData()
							data.Price = 7
							data.AutoUpdatePrice = false
							local spawnItem = Isaac.Spawn(5,100,rare_mystery, Vector(320, 320), Vector(0,0), nil):ToPickup()
							spawnItem.Price = 7
							spawnItem.AutoUpdatePrice = false
							local data = spawnItem:GetData()
							data.Price = 7
							data.AutoUpdatePrice = false
							local spawnItem = Isaac.Spawn(5,100,rare_mystery, Vector(320, 320), Vector(0,0), nil):ToPickup()
							spawnItem.Price = 7
							spawnItem.AutoUpdatePrice = false
							local data = spawnItem:GetData()
							data.Price = 7
							data.AutoUpdatePrice = false
							local spawnItem = Isaac.Spawn(5,100,legendary_mystery, Vector(360, 320), Vector(0,0), nil):ToPickup()
							spawnItem.Price = 15
							spawnItem.AutoUpdatePrice = false
							local data = spawnItem:GetData()
							data.Price = 15
							data.AutoUpdatePrice = false
							local spawnItem = Isaac.Spawn(5,100,legendary_mystery, Vector(360, 320), Vector(0,0), nil):ToPickup()
							spawnItem.Price = 15
							spawnItem.AutoUpdatePrice = false
							local data = spawnItem:GetData()
							data.Price = 15
							data.AutoUpdatePrice = false
							local spawnItem = Isaac.Spawn(5,100,legendary_mystery, Vector(360, 320), Vector(0,0), nil):ToPickup()
							spawnItem.Price = 15
							spawnItem.AutoUpdatePrice = false
							local data = spawnItem:GetData()
							data.Price = 15
							data.AutoUpdatePrice = false
							local spawnItem = Isaac.Spawn(5,100,legendary_mystery, Vector(360, 320), Vector(0,0), nil):ToPickup()
							spawnItem.Price = 15
							spawnItem.AutoUpdatePrice = false
							local data = spawnItem:GetData()
							data.Price = 15
							data.AutoUpdatePrice = false
							local spawnItem = Isaac.Spawn(5,100,legendary_mystery, Vector(360, 320), Vector(0,0), nil):ToPickup()
							spawnItem.Price = 15
							spawnItem.AutoUpdatePrice = false
							local data = spawnItem:GetData()
							data.Price = 15
							data.AutoUpdatePrice = false
							local spawnItem = Isaac.Spawn(5,100,legendary_mystery, Vector(360, 320), Vector(0,0), nil):ToPickup()
							spawnItem.Price = 15
							spawnItem.AutoUpdatePrice = false
							local data = spawnItem:GetData()
							data.Price = 15
							data.AutoUpdatePrice = false
							local spawnItem = Isaac.Spawn(5,100,legendary_mystery, Vector(360, 320), Vector(0,0), nil):ToPickup()
							spawnItem.Price = 15
							spawnItem.AutoUpdatePrice = false
							local data = spawnItem:GetData()
							data.Price = 15
							data.AutoUpdatePrice = false
							local spawnItem = Isaac.Spawn(5,100,legendary_mystery, Vector(360, 320), Vector(0,0), nil):ToPickup()
							spawnItem.Price = 15
							spawnItem.AutoUpdatePrice = false
							local data = spawnItem:GetData()
							data.Price = 15
							data.AutoUpdatePrice = false
							local spawnItem = Isaac.Spawn(5,100,legendary_mystery, Vector(360, 320), Vector(0,0), nil):ToPickup()
							spawnItem.Price = 15
							spawnItem.AutoUpdatePrice = false
							local data = spawnItem:GetData()
							data.Price = 15
							data.AutoUpdatePrice = false
							local spawnItem = Isaac.Spawn(5,100,legendary_mystery, Vector(360, 320), Vector(0,0), nil):ToPickup()
							spawnItem.Price = 15
							spawnItem.AutoUpdatePrice = false
							local data = spawnItem:GetData()
							data.Price = 15
							data.AutoUpdatePrice = false
						end
					end
				end
			end
		end
	end
end

MetalMod:AddCallback(ModCallbacks.MC_POST_NEW_ROOM,MetalMod.onNewRoom)

--function MetalMod:onUpdate()
	--for playerNum = 1, Game():GetNumPlayers() do
	--	local player = Game():GetPlayer(playerNum)
		--if player:GetName() == "Tainted Metal" then
			--local room = Game():GetRoom()
			--local ent = Isaac.FindByType(5, 20, 1)
			--for i=1, #ent do
			--	local pos = ent[i].Position
			--	ent[i]:Remove()
			--	Isaac.Spawn(5,20,2, pos, Vector(0,0), player)
			--end
		--end
	--end
--end

--MetalMod:AddCallback(ModCallbacks.MC_POST_UPDATE, MetalMod.onUpdate)